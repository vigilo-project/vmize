//! dm-verity hash tree generation using veritysetup.

use std::path::Path;
use std::process::Command;

use format::VerityMetadata;
use super::{Result, VerityError};

/// Default parameters for verity formatting.
#[derive(Debug, Clone)]
pub struct VerityParams {
    pub algorithm: String,
    pub data_block_size: u32,
    pub hash_block_size: u32,
}

impl Default for VerityParams {
    fn default() -> Self {
        Self {
            algorithm: "sha256".to_string(),
            data_block_size: 4096,
            hash_block_size: 4096,
        }
    }
}

/// Formatter for creating dm-verity hash trees.
pub struct VerityFormatter;

impl VerityFormatter {
    /// Find veritysetup binary path.
    pub fn find_veritysetup() -> Result<String> {
        which::which("veritysetup")
            .map(|p| p.to_string_lossy().to_string())
            .map_err(|_| VerityError::ToolNotFound("veritysetup".to_string()))
    }

    /// Format a data file and create a verity hash tree.
    ///
    /// Returns VerityMetadata containing the root hash and parameters.
    pub fn format(
        data_path: &Path,
        hash_output_path: &Path,
        params: &VerityParams,
    ) -> Result<VerityMetadata> {
        let veritysetup = Self::find_veritysetup()?;

        let output = Command::new(&veritysetup)
            .arg("format")
            .arg(data_path)
            .arg(hash_output_path)
            .arg("--hash")
            .arg(&params.algorithm)
            .arg("--data-block-size")
            .arg(params.data_block_size.to_string())
            .arg("--hash-block-size")
            .arg(params.hash_block_size.to_string())
            .output()?;

        if !output.status.success() {
            let stderr = String::from_utf8_lossy(&output.stderr);
            if stderr.contains("Permission denied") {
                return Err(VerityError::PermissionDenied);
            }
            return Err(VerityError::VeritysetupFailed(stderr.to_string()));
        }

        // Parse output to extract root hash and other metadata
        let stdout = String::from_utf8_lossy(&output.stdout);
        let root_hash = Self::parse_root_hash(&stdout)?;
        let salt = Self::parse_salt(&stdout);
        let data_size = std::fs::metadata(data_path)?.len();

        Ok(VerityMetadata {
            algorithm: params.algorithm.clone(),
            root_hash,
            salt,
            data_block_size: params.data_block_size,
            hash_block_size: params.hash_block_size,
            data_size,
        })
    }

    /// Parse root hash from veritysetup output.
    fn parse_root_hash(output: &str) -> Result<String> {
        // veritysetup format output contains: "Root hash: <hash>"
        for line in output.lines() {
            if line.starts_with("Root hash:") {
                let hash = line.trim_start_matches("Root hash:").trim();
                return Ok(hash.to_string());
            }
        }
        Err(VerityError::InvalidOutput("Root hash not found in veritysetup output".to_string()))
    }

    /// Parse salt from veritysetup output (optional).
    fn parse_salt(output: &str) -> Option<String> {
        for line in output.lines() {
            if line.starts_with("Salt:") {
                let salt = line.trim_start_matches("Salt:").trim();
                if salt != "-" && !salt.is_empty() {
                    return Some(salt.to_string());
                }
            }
        }
        None
    }

    /// Check if veritysetup is available.
    pub fn is_available() -> bool {
        Self::find_veritysetup().is_ok()
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_verity_params_default() {
        let params = VerityParams::default();
        assert_eq!(params.algorithm, "sha256");
        assert_eq!(params.data_block_size, 4096);
        assert_eq!(params.hash_block_size, 4096);
    }

    #[test]
    fn test_parse_root_hash() {
        let output = "VERITY header information for test.squashfs
Root hash:      abc123def456789
Salt:           -
";
        let hash = VerityFormatter::parse_root_hash(output).unwrap();
        assert_eq!(hash, "abc123def456789");
    }

    #[test]
    fn test_parse_salt_none() {
        let output = "Salt:           -";
        let salt = VerityFormatter::parse_salt(output);
        assert!(salt.is_none());
    }

    #[test]
    fn test_parse_salt_some() {
        let output = "Salt:           deadbeef1234";
        let salt = VerityFormatter::parse_salt(output);
        assert_eq!(salt, Some("deadbeef1234".to_string()));
    }
}
