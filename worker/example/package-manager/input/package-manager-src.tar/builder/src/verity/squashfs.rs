//! Squashfs filesystem creation using mksquashfs.

use std::path::Path;
use std::process::Command;

use super::{Result, VerityError};

/// Options for squashfs creation.
#[derive(Debug, Clone)]
pub struct SquashfsOptions {
    /// Compression algorithm (lz4, gzip, zstd, xz, lzo)
    pub compression: String,
    /// Block size in bytes (default: 131072)
    pub block_size: u32,
    /// Number of compression threads (default: use all CPUs)
    pub processors: Option<u32>,
}

impl Default for SquashfsOptions {
    fn default() -> Self {
        Self {
            compression: "lz4".to_string(),
            block_size: 131072,
            processors: None,
        }
    }
}

/// Builder for creating squashfs filesystem images.
pub struct SquashfsBuilder;

impl SquashfsBuilder {
    /// Find mksquashfs binary path.
    pub fn find_mksquashfs() -> Result<String> {
        which::which("mksquashfs")
            .map(|p| p.to_string_lossy().to_string())
            .map_err(|_| VerityError::ToolNotFound("mksquashfs".to_string()))
    }

    /// Create a squashfs filesystem from a source directory.
    pub fn build(source_dir: &Path, output_path: &Path, options: &SquashfsOptions) -> Result<()> {
        let mksquashfs = Self::find_mksquashfs()?;

        let mut cmd = Command::new(&mksquashfs);
        cmd.arg(source_dir)
            .arg(output_path)
            .arg("-comp")
            .arg(&options.compression)
            .arg("-b")
            .arg(options.block_size.to_string())
            .arg("-noappend");

        if let Some(procs) = options.processors {
            cmd.arg("-processors").arg(procs.to_string());
        }

        let output = cmd.output()?;

        if !output.status.success() {
            let stderr = String::from_utf8_lossy(&output.stderr);
            if stderr.contains("Permission denied") || stderr.contains("Operation not permitted") {
                return Err(VerityError::PermissionDenied);
            }
            return Err(VerityError::SquashfsFailed(stderr.to_string()));
        }

        Ok(())
    }

    /// Check if mksquashfs is available.
    pub fn is_available() -> bool {
        Self::find_mksquashfs().is_ok()
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_squashfs_options_default() {
        let opts = SquashfsOptions::default();
        assert_eq!(opts.compression, "lz4");
        assert_eq!(opts.block_size, 131072);
        assert!(opts.processors.is_none());
    }
}
