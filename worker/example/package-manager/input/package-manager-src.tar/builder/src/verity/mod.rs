//! Verity module for creating squashfs and dm-verity hash trees.

mod squashfs;
mod formatter;

pub use squashfs::{SquashfsBuilder, SquashfsOptions};
pub use formatter::{VerityFormatter, VerityParams};

use std::io;
use thiserror::Error;

/// Errors for verity operations in builder.
#[derive(Debug, Error)]
pub enum VerityError {
    #[error("mksquashfs failed: {0}")]
    SquashfsFailed(String),

    #[error("veritysetup failed: {0}")]
    VeritysetupFailed(String),

    #[error("tool not found: {0}")]
    ToolNotFound(String),

    #[error("permission denied (root required)")]
    PermissionDenied,

    #[error("invalid output: {0}")]
    InvalidOutput(String),

    #[error("IO error: {0}")]
    Io(#[from] io::Error),
}

pub type Result<T> = std::result::Result<T, VerityError>;
