pub mod config;
pub mod verity;

pub use config::ConfigGenerator;
pub use verity::{SquashfsBuilder, SquashfsOptions, VerityFormatter, VerityParams};

use std::path::Path;
use tempfile::TempDir;

use format::{Package, PackageManifest};

/// Convert a V1 package to a V2 package with squashfs and dm-verity.
pub fn convert_v1_to_v2(
    v1_package_path: &Path,
    output_path: &Path,
    compression: Option<String>,
) -> anyhow::Result<()> {
    let temp_dir = TempDir::new()?;
    let extract_dir = temp_dir.path().join("extract");

    // Step 1: Extract V1 package
    eprintln!("Extracting V1 package...");
    let manifest = Package::extract(v1_package_path, &extract_dir)?;

    if manifest.is_v2() {
        anyhow::bail!("Package is already a V2 package");
    }

    let rootfs_dir = extract_dir.join("rootfs");
    let config_path = extract_dir.join("config.json");

    if !rootfs_dir.exists() {
        anyhow::bail!("V1 package does not contain rootfs directory");
    }

    // Create required mount point directories for runc
    eprintln!("Creating mount point directories in rootfs...");
    std::fs::create_dir_all(rootfs_dir.join("dev"))?;
    std::fs::create_dir_all(rootfs_dir.join("proc"))?;
    std::fs::create_dir_all(rootfs_dir.join("tmp"))?;
    #[cfg(unix)]
    {
        use std::os::unix::fs::PermissionsExt;
        std::fs::set_permissions(rootfs_dir.join("tmp"), std::fs::Permissions::from_mode(0o1777))?;
    }

    // Step 2: Create squashfs from rootfs
    let squashfs_path = temp_dir.path().join("rootfs.squashfs");
    eprintln!("Creating squashfs image...");

    // Parse compression option
    let mut options = SquashfsOptions::default();
    options.compression = match compression.as_deref() {
        Some("gzip") => "gzip".to_string(),
        Some("zstd") => "zstd".to_string(),
        Some("lz4") | None => "lz4".to_string(),
        Some(c) => anyhow::bail!("Unknown compression: {}. Use: lz4, gzip, zstd", c),
    };

    SquashfsBuilder::build(&rootfs_dir, &squashfs_path, &options)?;

    // Step 3: Generate verity hash
    let hash_path = temp_dir.path().join("rootfs.squashfs.hash");
    eprintln!("Generating dm-verity hash tree...");
    let verity_metadata = VerityFormatter::format(
        &squashfs_path,
        &hash_path,
        &VerityParams::default(),
    )?;
    eprintln!("Root hash: {}", verity_metadata.root_hash);

    // Step 4: Create V2 manifest
    let v2_manifest = PackageManifest::new_v2(
        manifest.name,
        manifest.version,
        manifest.image_ref,
        verity_metadata,
    );

    // Step 5: Read config.json
    let config_json = if config_path.exists() {
        std::fs::read_to_string(&config_path)?
    } else {
        // If no config.json, generate one
        ConfigGenerator::generate_config_json(None, None, None, false)?
    };

    // Step 6: Create V2 package
    eprintln!("Creating V2 package...");
    Package::create_v2(output_path, &squashfs_path, &hash_path, &config_json, &v2_manifest)?;

    eprintln!("V2 package created at {}", output_path.display());
    Ok(())
}

/// Build a V1 package from an existing rootfs directory (no registry pull).
pub fn build_from_rootfs(
    rootfs_path: &Path,
    output_path: &Path,
    manifest: &PackageManifest,
    command: Option<Vec<String>>,
    terminal: bool,
) -> anyhow::Result<()> {
    let config_json = ConfigGenerator::generate_config_json(command, None, None, terminal)?;
    Package::create(output_path, rootfs_path, &config_json, manifest)?;
    Ok(())
}

/// Build a V2 package from an existing rootfs directory.
/// Creates squashfs and verity hash, then packages them.
pub fn build_v2_from_rootfs(
    rootfs_path: &Path,
    output_path: &Path,
    manifest_name: &str,
    manifest_version: &str,
    image_ref: &str,
    command: Option<Vec<String>>,
    terminal: bool,
) -> anyhow::Result<()> {
    let temp_dir = TempDir::new()?;

    // Step 1: Create squashfs from rootfs
    let squashfs_path = temp_dir.path().join("rootfs.squashfs");
    eprintln!("Creating squashfs image...");
    SquashfsBuilder::build(rootfs_path, &squashfs_path, &SquashfsOptions::default())?;

    // Step 2: Generate verity hash
    let hash_path = temp_dir.path().join("rootfs.squashfs.hash");
    eprintln!("Generating dm-verity hash tree...");
    let verity_metadata = VerityFormatter::format(
        &squashfs_path,
        &hash_path,
        &VerityParams::default(),
    )?;
    eprintln!("Root hash: {}", verity_metadata.root_hash);

    // Step 3: Generate config.json
    let config_json = ConfigGenerator::generate_config_json(command, None, None, terminal)?;

    // Step 4: Create V2 manifest
    let manifest = PackageManifest::new_v2(
        manifest_name.to_string(),
        manifest_version.to_string(),
        image_ref.to_string(),
        verity_metadata,
    );

    // Step 5: Create V2 package
    eprintln!("Creating V2 package...");
    Package::create_v2(output_path, &squashfs_path, &hash_path, &config_json, &manifest)?;

    Ok(())
}
