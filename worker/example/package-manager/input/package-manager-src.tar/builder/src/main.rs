use std::path::PathBuf;
use std::process::Command;

use clap::Parser;
use format::PackageManifest;

use builder::{build_from_rootfs, convert_v1_to_v2};

const UBUNTU_ROOTFS_URL: &str =
    "https://cloud-images.ubuntu.com/noble/20260131/noble-server-cloudimg-amd64-root.tar.xz";

#[derive(Parser, Debug)]
#[command(name = "builder", version, about = "Build container packages")]
struct Cli {
    #[command(subcommand)]
    command: Commands,
}

#[derive(clap::Subcommand, Debug)]
enum Commands {
    /// Download and extract the Ubuntu cloud image rootfs
    Download {
        /// Output directory for the extracted rootfs
        #[arg(short, long)]
        output: PathBuf,
    },
    /// Bundle a rootfs directory into a V1 package
    Bundle {
        /// Path to the rootfs directory
        rootfs_dir: PathBuf,

        /// Output package path (tar.gz)
        #[arg(short, long)]
        output: PathBuf,
    },
    /// Convert a V1 package to V2 (squashfs + dm-verity)
    Convert {
        /// Input V1 package path (tar.gz)
        input: PathBuf,

        /// Output V2 package path (tar.gz)
        #[arg(short, long)]
        output: PathBuf,

        /// Squashfs compression algorithm: lz4 (default), gzip, zstd
        #[arg(long)]
        compression: Option<String>,
    },
}

fn main() -> anyhow::Result<()> {
    let cli = Cli::parse();

    match cli.command {
        Commands::Download { output } => download(output)?,
        Commands::Bundle { rootfs_dir, output } => bundle(rootfs_dir, output)?,
        Commands::Convert {
            input,
            output,
            compression,
        } => convert(input, output, compression)?,
    }

    Ok(())
}

fn download(output: PathBuf) -> anyhow::Result<()> {
    eprintln!("Downloading Ubuntu cloud image rootfs...");
    eprintln!("URL: {}", UBUNTU_ROOTFS_URL);

    std::fs::create_dir_all(&output)?;

    let status = Command::new("sh")
        .arg("-c")
        .arg(format!(
            "curl -fSL '{}' | tar xJf - -C '{}'",
            UBUNTU_ROOTFS_URL,
            output.display()
        ))
        .status()
        .map_err(|e| anyhow::anyhow!("Failed to run curl | tar: {}", e))?;

    if !status.success() {
        anyhow::bail!("Download and extraction failed");
    }

    eprintln!("Rootfs extracted to {}", output.display());
    Ok(())
}

fn bundle(rootfs_dir: PathBuf, output: PathBuf) -> anyhow::Result<()> {
    if !rootfs_dir.is_dir() {
        anyhow::bail!("Rootfs directory does not exist: {}", rootfs_dir.display());
    }

    eprintln!("Bundling rootfs into V1 package...");

    let manifest = PackageManifest::new(
        "ubuntu".to_string(),
        "noble".to_string(),
        UBUNTU_ROOTFS_URL.to_string(),
    );

    build_from_rootfs(&rootfs_dir, &output, &manifest, None, false)?;

    eprintln!("Package created at {}", output.display());
    Ok(())
}

fn convert(input: PathBuf, output: PathBuf, compression: Option<String>) -> anyhow::Result<()> {
    eprintln!("Converting V1 package to V2...");

    convert_v1_to_v2(&input, &output, compression)?;

    eprintln!("Conversion complete!");
    Ok(())
}
