use oci_spec::runtime::{
    LinuxBuilder, LinuxMemoryBuilder, LinuxNamespaceBuilder, LinuxNamespaceType,
    LinuxResourcesBuilder, MountBuilder, ProcessBuilder, RootBuilder, Spec, SpecBuilder,
    UserBuilder,
};
use std::fs;
use std::path::Path;
use thiserror::Error;

#[derive(Error, Debug)]
pub enum ConfigError {
    #[error("Failed to generate config: {0}")]
    ConfigGeneration(String),

    #[error("IO error: {0}")]
    Io(#[from] std::io::Error),

    #[error("OCI spec error: {0}")]
    OciSpec(String),
}

/// Convert any OCI builder error into `ConfigError::OciSpec`.
fn oci_err(e: impl ToString) -> ConfigError {
    ConfigError::OciSpec(e.to_string())
}

pub struct ConfigGenerator;

impl ConfigGenerator {
    /// Build a complete OCI runtime spec.
    ///
    /// This is the single source of truth for OCI config generation.
    /// Both `generate()` (file output) and `generate_config_json()` (string output)
    /// delegate to this method.
    fn build_spec(
        rootfs_path: &str,
        command: Option<Vec<String>>,
        env: Option<Vec<String>>,
        working_dir: Option<String>,
        terminal: bool,
    ) -> Result<Spec, ConfigError> {
        let args = command.unwrap_or_else(|| vec!["/bin/bash".to_string()]);
        let env = env.unwrap_or_else(|| {
            vec![
                "PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin".to_string(),
                "TERM=xterm".to_string(),
            ]
        });
        let cwd = working_dir.unwrap_or_else(|| "/".to_string());

        let process = ProcessBuilder::default()
            .terminal(terminal)
            .user(
                UserBuilder::default()
                    .uid(0u32)
                    .gid(0u32)
                    .build()
                    .map_err(oci_err)?,
            )
            .args(args)
            .env(env)
            .cwd(cwd)
            .no_new_privileges(true)
            .build()
            .map_err(oci_err)?;

        let root = RootBuilder::default()
            .path(rootfs_path)
            .readonly(false)
            .build()
            .map_err(oci_err)?;

        let mounts = Self::build_mounts()?;
        let linux = Self::build_linux()?;

        SpecBuilder::default()
            .version("1.0.2")
            .root(root)
            .process(process)
            .mounts(mounts)
            .linux(linux)
            .hostname("container")
            .build()
            .map_err(oci_err)
    }

    /// Build the standard container mount list.
    fn build_mounts() -> Result<Vec<oci_spec::runtime::Mount>, ConfigError> {
        let mount = |dest: &str, typ: &str, src: &str, opts: Option<Vec<&str>>| {
            let b = MountBuilder::default()
                .destination(dest)
                .typ(typ)
                .source(src);
            let b = match opts {
                Some(o) => b.options(o.into_iter().map(String::from).collect::<Vec<_>>()),
                None => b,
            };
            b.build().map_err(oci_err)
        };

        Ok(vec![
            mount("/proc", "proc", "proc", None)?,
            mount("/dev", "tmpfs", "tmpfs", Some(vec![
                "nosuid", "strictatime", "mode=755", "size=65536k",
            ]))?,
            mount("/dev/pts", "devpts", "devpts", Some(vec![
                "nosuid", "noexec", "newinstance", "ptmxmode=0666", "mode=0620",
            ]))?,
            mount("/dev/shm", "tmpfs", "shm", Some(vec![
                "nosuid", "noexec", "nodev", "mode=1777", "size=65536k",
            ]))?,
            mount("/sys", "sysfs", "sysfs", Some(vec![
                "nosuid", "noexec", "nodev", "ro",
            ]))?,
        ])
    }

    /// Build the Linux namespace and resource configuration.
    fn build_linux() -> Result<oci_spec::runtime::Linux, ConfigError> {
        let namespace_types = [
            LinuxNamespaceType::Pid,
            LinuxNamespaceType::Network,
            LinuxNamespaceType::Ipc,
            LinuxNamespaceType::Uts,
            LinuxNamespaceType::Mount,
            LinuxNamespaceType::Cgroup,
        ];

        let namespaces = namespace_types
            .into_iter()
            .map(|typ| {
                LinuxNamespaceBuilder::default()
                    .typ(typ)
                    .build()
                    .map_err(oci_err)
            })
            .collect::<Result<Vec<_>, _>>()?;

        let memory = LinuxMemoryBuilder::default()
            .limit(512 * 1024 * 1024)
            .build()
            .map_err(oci_err)?;

        let resources = LinuxResourcesBuilder::default()
            .memory(memory)
            .build()
            .map_err(oci_err)?;

        LinuxBuilder::default()
            .namespaces(namespaces)
            .resources(resources)
            .build()
            .map_err(oci_err)
    }

    /// Generate an OCI config and write it to a file.
    pub fn generate(
        rootfs_path: &Path,
        output_path: &Path,
        command: Option<Vec<String>>,
        env: Option<Vec<String>>,
        working_dir: Option<String>,
        terminal: bool,
    ) -> Result<(), ConfigError> {
        let rootfs_abs = rootfs_path.canonicalize().map_err(|e| {
            ConfigError::ConfigGeneration(format!("Invalid rootfs path: {}", e))
        })?;

        let spec = Self::build_spec(
            &rootfs_abs.to_string_lossy(),
            command,
            env,
            working_dir,
            terminal,
        )?;

        let json = serde_json::to_string_pretty(&spec)
            .map_err(|e| ConfigError::ConfigGeneration(e.to_string()))?;

        if let Some(parent) = output_path.parent() {
            fs::create_dir_all(parent)?;
        }

        fs::write(output_path, json)?;
        Ok(())
    }

    /// Generate config.json content as a string (for embedding in packages).
    pub fn generate_config_json(
        command: Option<Vec<String>>,
        env: Option<Vec<String>>,
        working_dir: Option<String>,
        terminal: bool,
    ) -> Result<String, ConfigError> {
        let spec = Self::build_spec("rootfs", command, env, working_dir, terminal)?;
        serde_json::to_string_pretty(&spec)
            .map_err(|e| ConfigError::ConfigGeneration(e.to_string()))
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_generate_config_with_terminal_true() {
        let config = ConfigGenerator::generate_config_json(None, None, None, true).unwrap();
        let spec: oci_spec::runtime::Spec = serde_json::from_str(&config).unwrap();
        assert!(spec.process().as_ref().unwrap().terminal().unwrap());
    }

    #[test]
    fn test_generate_config_with_terminal_false() {
        let config = ConfigGenerator::generate_config_json(None, None, None, false).unwrap();
        let spec: oci_spec::runtime::Spec = serde_json::from_str(&config).unwrap();
        assert!(!spec.process().as_ref().unwrap().terminal().unwrap());
    }

    #[test]
    fn test_generate_config_with_custom_command() {
        let cmd = vec!["/bin/bash".to_string(), "-c".to_string(), "echo hello".to_string()];
        let config = ConfigGenerator::generate_config_json(Some(cmd.clone()), None, None, false).unwrap();
        let spec: oci_spec::runtime::Spec = serde_json::from_str(&config).unwrap();
        let args = spec.process().as_ref().unwrap().args().as_ref().unwrap();
        assert_eq!(args, &cmd);
    }
}
