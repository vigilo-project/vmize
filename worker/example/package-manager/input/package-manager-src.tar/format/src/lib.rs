//! Package format library — validates OCI config and holds verity metadata.

use serde::{Deserialize, Serialize};
use std::io;
use thiserror::Error;

#[derive(Error, Debug)]
pub enum FormatError {
    #[error("IO error: {0}")]
    Io(#[from] io::Error),

    #[error("JSON error: {0}")]
    Json(#[from] serde_json::Error),

    #[error("Invalid package: {0}")]
    InvalidPackage(String),
}

pub type Result<T> = std::result::Result<T, FormatError>;

/// dm-verity metadata for integrity verification.
#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
pub struct VerityMetadata {
    /// Hash algorithm (e.g., "sha256")
    pub algorithm: String,
    /// Root hash of the verity tree
    pub root_hash: String,
    /// Optional salt value
    #[serde(skip_serializing_if = "Option::is_none")]
    pub salt: Option<String>,
    /// Data block size in bytes
    pub data_block_size: u32,
    /// Hash block size in bytes
    pub hash_block_size: u32,
    /// Size of the data device in bytes
    pub data_size: u64,
}

/// Validate an OCI runtime config.json string.
///
/// Checks required fields: ociVersion, process.args, root.path, root.readonly=true,
/// and at least one linux namespace.
pub fn validate_config(config_json: &str) -> Result<()> {
    let config: serde_json::Value =
        serde_json::from_str(config_json).map_err(|e| FormatError::InvalidPackage(format!("invalid JSON: {e}")))?;

    // ociVersion
    if config.get("ociVersion").and_then(|v| v.as_str()).is_none() {
        return Err(FormatError::InvalidPackage("missing ociVersion".into()));
    }

    // process.args
    let process = config
        .get("process")
        .ok_or_else(|| FormatError::InvalidPackage("missing process".into()))?;
    match process.get("args").and_then(|v| v.as_array()) {
        Some(args) if !args.is_empty() => {}
        _ => return Err(FormatError::InvalidPackage("process.args must be a non-empty array".into())),
    }

    // root.path and root.readonly
    let root = config
        .get("root")
        .ok_or_else(|| FormatError::InvalidPackage("missing root".into()))?;
    if root.get("path").and_then(|v| v.as_str()).is_none() {
        return Err(FormatError::InvalidPackage("missing root.path".into()));
    }
    match root.get("readonly").and_then(|v| v.as_bool()) {
        Some(true) => {}
        _ => return Err(FormatError::InvalidPackage("root.readonly must be true".into())),
    }

    // linux.namespaces
    let linux = config
        .get("linux")
        .ok_or_else(|| FormatError::InvalidPackage("missing linux".into()))?;
    match linux.get("namespaces").and_then(|v| v.as_array()) {
        Some(ns) if !ns.is_empty() => {}
        _ => return Err(FormatError::InvalidPackage("linux.namespaces must be a non-empty array".into())),
    }

    Ok(())
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_verity_metadata_serialization() {
        let verity = VerityMetadata {
            algorithm: "sha256".to_string(),
            root_hash: "abc123def456".to_string(),
            salt: Some("deadbeef".to_string()),
            data_block_size: 4096,
            hash_block_size: 4096,
            data_size: 8388608,
        };

        let json = serde_json::to_string(&verity).unwrap();
        let parsed: VerityMetadata = serde_json::from_str(&json).unwrap();

        assert_eq!(parsed.algorithm, "sha256");
        assert_eq!(parsed.root_hash, "abc123def456");
        assert_eq!(parsed.salt, Some("deadbeef".to_string()));
        assert_eq!(parsed.data_block_size, 4096);
        assert_eq!(parsed.data_size, 8388608);
    }

    #[test]
    fn test_verity_metadata_without_salt() {
        let json = r#"{"algorithm":"sha256","root_hash":"abc123","data_block_size":4096,"hash_block_size":4096,"data_size":1024}"#;
        let verity: VerityMetadata = serde_json::from_str(json).unwrap();
        assert_eq!(verity.salt, None);
    }

    #[test]
    fn test_validate_config_valid() {
        let config = r#"{
            "ociVersion": "1.0.2",
            "process": { "args": ["/bin/sh"] },
            "root": { "path": "rootfs", "readonly": true },
            "linux": { "namespaces": [{"type": "pid"}] }
        }"#;
        assert!(validate_config(config).is_ok());
    }

    #[test]
    fn test_validate_config_missing_oci_version() {
        let config = r#"{
            "process": { "args": ["/bin/sh"] },
            "root": { "path": "rootfs", "readonly": true },
            "linux": { "namespaces": [{"type": "pid"}] }
        }"#;
        let err = validate_config(config).unwrap_err();
        assert!(err.to_string().contains("ociVersion"));
    }

    #[test]
    fn test_validate_config_not_readonly() {
        let config = r#"{
            "ociVersion": "1.0.2",
            "process": { "args": ["/bin/sh"] },
            "root": { "path": "rootfs", "readonly": false },
            "linux": { "namespaces": [{"type": "pid"}] }
        }"#;
        let err = validate_config(config).unwrap_err();
        assert!(err.to_string().contains("readonly"));
    }

    #[test]
    fn test_validate_config_empty_args() {
        let config = r#"{
            "ociVersion": "1.0.2",
            "process": { "args": [] },
            "root": { "path": "rootfs", "readonly": true },
            "linux": { "namespaces": [{"type": "pid"}] }
        }"#;
        let err = validate_config(config).unwrap_err();
        assert!(err.to_string().contains("args"));
    }

    #[test]
    fn test_validate_config_missing_namespaces() {
        let config = r#"{
            "ociVersion": "1.0.2",
            "process": { "args": ["/bin/sh"] },
            "root": { "path": "rootfs", "readonly": true },
            "linux": {}
        }"#;
        let err = validate_config(config).unwrap_err();
        assert!(err.to_string().contains("namespaces"));
    }
}
