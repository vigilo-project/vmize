//! Package format library for creating and reading tar.gz packages.
//!
//! Supports two package formats:
//! - V1: rootfs directory (backward compatible)
//! - V2: squashfs with dm-verity integrity verification
//!
//! Package structure (V1):
//! ```text
//! package.tar.gz/
//! ├── manifest.json    # PackageManifest
//! ├── config.json      # OCI runtime config
//! └── rootfs/          # Container filesystem
//! ```
//!
//! Package structure (V2):
//! ```text
//! package.tar.gz/
//! ├── manifest.json        # PackageManifest with RootfsMetadata::Squashfs
//! ├── config.json          # OCI runtime config
//! ├── rootfs.squashfs      # Squashfs filesystem image
//! └── rootfs.squashfs.hash # dm-verity hash tree
//! ```

use chrono::{DateTime, Utc};
use flate2::read::GzDecoder;
use flate2::write::GzEncoder;
use flate2::Compression;
use serde::{Deserialize, Serialize};
use std::fs::{self, File};
use std::io::{self, BufReader, BufWriter, Read, Write};
#[cfg(unix)]
use std::os::unix::fs::PermissionsExt;
use std::path::Path;
use tar::{Archive, Builder, Header};
use thiserror::Error;

#[derive(Error, Debug)]
pub enum FormatError {
    #[error("IO error: {0}")]
    Io(#[from] io::Error),

    #[error("JSON error: {0}")]
    Json(#[from] serde_json::Error),

    #[error("Invalid package: {0}")]
    InvalidPackage(String),

    #[error("Tar error: {0}")]
    Tar(String),
}

pub type Result<T> = std::result::Result<T, FormatError>;

/// dm-verity metadata for integrity verification.
#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
pub struct VerityMetadata {
    /// Hash algorithm (e.g., "sha256")
    pub algorithm: String,
    /// Root hash of the verity tree
    pub root_hash: String,
    /// Optional salt value
    #[serde(skip_serializing_if = "Option::is_none")]
    pub salt: Option<String>,
    /// Data block size in bytes
    pub data_block_size: u32,
    /// Hash block size in bytes
    pub hash_block_size: u32,
    /// Size of the data device in bytes
    pub data_size: u64,
}

/// Rootfs format metadata.
#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, Default)]
#[serde(tag = "type", rename_all = "lowercase")]
pub enum RootfsMetadata {
    /// V1 format: rootfs directory
    #[default]
    Directory,
    /// V2 format: squashfs with dm-verity
    Squashfs {
        /// dm-verity metadata for integrity verification
        verity: VerityMetadata,
    },
}

/// Package manifest containing metadata about the package.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct PackageManifest {
    /// Package name
    pub name: String,
    /// Package version
    pub version: String,
    /// Creation timestamp
    pub created_at: DateTime<Utc>,
    /// Original image reference (e.g., "ubuntu:24.04")
    pub image_ref: String,
    /// Rootfs format metadata (defaults to Directory for V1 compatibility)
    #[serde(default)]
    pub rootfs: RootfsMetadata,
}

impl PackageManifest {
    pub fn new(name: String, version: String, image_ref: String) -> Self {
        Self {
            name,
            version,
            created_at: Utc::now(),
            image_ref,
            rootfs: RootfsMetadata::Directory,
        }
    }

    /// Create a V2 manifest with squashfs and verity metadata
    pub fn new_v2(
        name: String,
        version: String,
        image_ref: String,
        verity: VerityMetadata,
    ) -> Self {
        Self {
            name,
            version,
            created_at: Utc::now(),
            image_ref,
            rootfs: RootfsMetadata::Squashfs { verity },
        }
    }

    /// Check if this is a V2 package (squashfs with verity)
    pub fn is_v2(&self) -> bool {
        matches!(self.rootfs, RootfsMetadata::Squashfs { .. })
    }
}

/// Package operations for creating and extracting packages.
pub struct Package;

impl Package {
    /// Begin a new package tar.gz, returning the tar builder.
    fn begin_package(output_path: &Path) -> Result<Builder<GzEncoder<BufWriter<File>>>> {
        let file = File::create(output_path)?;
        let buf_writer = BufWriter::new(file);
        let encoder = GzEncoder::new(buf_writer, Compression::default());
        Ok(Builder::new(encoder))
    }

    /// Finalize the tar builder, flushing all data.
    fn finish_package(builder: Builder<GzEncoder<BufWriter<File>>>) -> Result<()> {
        builder
            .into_inner()
            .map_err(|e| FormatError::Tar(e.to_string()))?
            .finish()?;
        Ok(())
    }

    /// Append a JSON-serialized entry (e.g. manifest.json, config.json) to the tar archive.
    fn append_json_entry<W: Write>(
        builder: &mut Builder<W>,
        archive_path: &str,
        content: &[u8],
    ) -> Result<()> {
        let mut header = Header::new_gnu();
        header.set_path(archive_path)?;
        header.set_size(content.len() as u64);
        header.set_mode(0o644);
        header.set_cksum();
        builder.append(&header, content)?;
        Ok(())
    }

    /// Create a V1 package tar.gz from a rootfs directory, config.json, and manifest.
    pub fn create(
        output_path: &Path,
        rootfs_path: &Path,
        config_json: &str,
        manifest: &PackageManifest,
    ) -> Result<()> {
        let mut builder = Self::begin_package(output_path)?;

        let manifest_json = serde_json::to_string_pretty(manifest)?;
        Self::append_json_entry(&mut builder, "manifest.json", manifest_json.as_bytes())?;
        Self::append_json_entry(&mut builder, "config.json", config_json.as_bytes())?;

        Self::add_directory_to_tar(&mut builder, rootfs_path, Path::new("rootfs"))?;

        Self::finish_package(builder)
    }

    /// Create a V2 package tar.gz with squashfs and hash files.
    pub fn create_v2(
        output_path: &Path,
        squashfs_path: &Path,
        hash_path: &Path,
        config_json: &str,
        manifest: &PackageManifest,
    ) -> Result<()> {
        let mut builder = Self::begin_package(output_path)?;

        let manifest_json = serde_json::to_string_pretty(manifest)?;
        Self::append_json_entry(&mut builder, "manifest.json", manifest_json.as_bytes())?;
        Self::append_json_entry(&mut builder, "config.json", config_json.as_bytes())?;

        Self::add_file_to_tar(&mut builder, squashfs_path, Path::new("rootfs.squashfs"))?;
        Self::add_file_to_tar(&mut builder, hash_path, Path::new("rootfs.squashfs.hash"))?;

        Self::finish_package(builder)
    }

    fn add_directory_to_tar<W: Write>(
        builder: &mut Builder<W>,
        source_path: &Path,
        archive_path: &Path,
    ) -> Result<()> {
        if source_path.is_dir() {
            let mut header = Header::new_gnu();
            header.set_entry_type(tar::EntryType::Directory);
            let archive_path_str = archive_path.to_string_lossy().to_string() + "/";
            header.set_path(&archive_path_str)?;
            header.set_size(0);
            header.set_mode(0o755);
            header.set_cksum();
            builder.append(&header, io::empty())?;

            for entry in fs::read_dir(source_path)? {
                let entry = entry?;
                let entry_path = entry.path();
                let file_name = entry.file_name();
                let new_archive_path = archive_path.join(&file_name);

                let file_type = entry.file_type()?;
                if file_type.is_symlink() {
                    Self::add_symlink_to_tar(builder, &entry_path, &new_archive_path)?;
                } else if file_type.is_dir() {
                    Self::add_directory_to_tar(builder, &entry_path, &new_archive_path)?;
                } else if file_type.is_file() {
                    Self::add_file_to_tar(builder, &entry_path, &new_archive_path)?;
                }
            }
        }
        Ok(())
    }

    fn add_file_to_tar<W: Write>(
        builder: &mut Builder<W>,
        source_path: &Path,
        archive_path: &Path,
    ) -> Result<()> {
        let metadata = fs::metadata(source_path)?;
        let mut file = File::open(source_path)?;

        let mut header = Header::new_gnu();
        header.set_path(archive_path)?;
        header.set_size(metadata.len());
        header.set_mode(metadata.permissions().mode());
        header.set_cksum();

        builder.append(&header, &mut file)?;
        Ok(())
    }

    fn add_symlink_to_tar<W: Write>(
        builder: &mut Builder<W>,
        source_path: &Path,
        archive_path: &Path,
    ) -> Result<()> {
        let link_target = fs::read_link(source_path)?;

        let mut header = Header::new_gnu();
        header.set_entry_type(tar::EntryType::Symlink);
        header.set_path(archive_path)?;
        header.set_size(0);
        header.set_mode(0o777);
        header
            .set_link_name(&link_target)
            .map_err(|e| FormatError::Tar(e.to_string()))?;
        header.set_cksum();

        builder.append(&header, io::empty())?;
        Ok(())
    }

    /// Extract a package to a directory. Returns the extracted manifest.
    pub fn extract(package_path: &Path, output_dir: &Path) -> Result<PackageManifest> {
        let file = File::open(package_path)?;
        let buf_reader = BufReader::new(file);
        let decoder = GzDecoder::new(buf_reader);
        let mut archive = Archive::new(decoder);

        fs::create_dir_all(output_dir)?;

        let mut manifest: Option<PackageManifest> = None;

        for entry in archive.entries()? {
            let mut entry = entry?;
            let path = entry.path()?.into_owned();
            let path_str = path.to_string_lossy();

            if path_str == "manifest.json" {
                let mut contents = String::new();
                entry.read_to_string(&mut contents)?;
                manifest = Some(serde_json::from_str(&contents)?);
            } else {
                let dest_path = output_dir.join(&path);
                if let Some(parent) = dest_path.parent() {
                    fs::create_dir_all(parent)?;
                }
                entry.unpack(&dest_path)?;
            }
        }

        manifest.ok_or_else(|| FormatError::InvalidPackage("Missing manifest.json".to_string()))
    }

    /// Read only the manifest from a package without fully extracting.
    pub fn read_manifest(package_path: &Path) -> Result<PackageManifest> {
        let file = File::open(package_path)?;
        let buf_reader = BufReader::new(file);
        let decoder = GzDecoder::new(buf_reader);
        let mut archive = Archive::new(decoder);

        for entry in archive.entries()? {
            let mut entry = entry?;
            let path = entry.path()?.into_owned();

            if path.to_string_lossy() == "manifest.json" {
                let mut contents = String::new();
                entry.read_to_string(&mut contents)?;
                return Ok(serde_json::from_str(&contents)?);
            }
        }

        Err(FormatError::InvalidPackage("Missing manifest.json".to_string()))
    }
}

#[cfg(not(unix))]
trait PermissionsExt {
    fn mode(&self) -> u32 { 0o644 }
}

#[cfg(not(unix))]
impl PermissionsExt for std::fs::Permissions {}

#[cfg(test)]
mod tests {
    use super::*;
    use tempfile::TempDir;

    #[test]
    fn test_verity_metadata_serialization() {
        let verity = VerityMetadata {
            algorithm: "sha256".to_string(),
            root_hash: "abc123def456".to_string(),
            salt: Some("deadbeef".to_string()),
            data_block_size: 4096,
            hash_block_size: 4096,
            data_size: 8388608,
        };

        let json = serde_json::to_string(&verity).unwrap();
        let parsed: VerityMetadata = serde_json::from_str(&json).unwrap();

        assert_eq!(parsed.algorithm, "sha256");
        assert_eq!(parsed.root_hash, "abc123def456");
        assert_eq!(parsed.salt, Some("deadbeef".to_string()));
        assert_eq!(parsed.data_block_size, 4096);
        assert_eq!(parsed.data_size, 8388608);
    }

    #[test]
    fn test_verity_metadata_without_salt() {
        let json = r#"{"algorithm":"sha256","root_hash":"abc123","data_block_size":4096,"hash_block_size":4096,"data_size":1024}"#;
        let verity: VerityMetadata = serde_json::from_str(json).unwrap();
        assert_eq!(verity.salt, None);
    }

    #[test]
    fn test_rootfs_metadata_directory() {
        let rootfs = RootfsMetadata::Directory;
        let json = serde_json::to_string(&rootfs).unwrap();
        assert!(json.contains(r#""type":"directory""#));

        let parsed: RootfsMetadata = serde_json::from_str(&json).unwrap();
        assert!(matches!(parsed, RootfsMetadata::Directory));
    }

    #[test]
    fn test_rootfs_metadata_squashfs() {
        let verity = VerityMetadata {
            algorithm: "sha256".to_string(),
            root_hash: "abc123".to_string(),
            salt: None,
            data_block_size: 4096,
            hash_block_size: 4096,
            data_size: 8388608,
        };
        let rootfs = RootfsMetadata::Squashfs { verity };

        let json = serde_json::to_string(&rootfs).unwrap();
        assert!(json.contains(r#""type":"squashfs""#));

        let parsed: RootfsMetadata = serde_json::from_str(&json).unwrap();
        match parsed {
            RootfsMetadata::Squashfs { verity } => assert_eq!(verity.root_hash, "abc123"),
            _ => panic!("Expected Squashfs variant"),
        }
    }

    #[test]
    fn test_v1_manifest_backward_compatibility() {
        let v1_json = r#"{"name":"test-package","version":"1.0.0","created_at":"2024-01-15T10:30:00Z","image_ref":"alpine:3.19"}"#;

        let manifest: PackageManifest = serde_json::from_str(v1_json).unwrap();
        assert_eq!(manifest.name, "test-package");
        assert!(matches!(manifest.rootfs, RootfsMetadata::Directory));
        assert!(!manifest.is_v2());
    }

    #[test]
    fn test_v2_manifest_with_squashfs() {
        let v2_json = r#"{"name":"test-package","version":"1.0.0","created_at":"2024-01-15T10:30:00Z","image_ref":"alpine:3.19","rootfs":{"type":"squashfs","verity":{"algorithm":"sha256","root_hash":"abc123def456","data_block_size":4096,"hash_block_size":4096,"data_size":8388608}}}"#;

        let manifest: PackageManifest = serde_json::from_str(v2_json).unwrap();
        assert!(manifest.is_v2());
        match &manifest.rootfs {
            RootfsMetadata::Squashfs { verity } => assert_eq!(verity.root_hash, "abc123def456"),
            _ => panic!("Expected Squashfs variant"),
        }
    }

    #[test]
    fn test_manifest_serialization() {
        let manifest = PackageManifest::new(
            "test-package".to_string(),
            "1.0.0".to_string(),
            "ubuntu:24.04".to_string(),
        );

        let json = serde_json::to_string(&manifest).unwrap();
        let parsed: PackageManifest = serde_json::from_str(&json).unwrap();

        assert_eq!(parsed.name, "test-package");
        assert_eq!(parsed.version, "1.0.0");
        assert_eq!(parsed.image_ref, "ubuntu:24.04");
        assert!(matches!(parsed.rootfs, RootfsMetadata::Directory));
    }

    #[test]
    fn test_manifest_new_v2() {
        let verity = VerityMetadata {
            algorithm: "sha256".to_string(),
            root_hash: "abc123".to_string(),
            salt: None,
            data_block_size: 4096,
            hash_block_size: 4096,
            data_size: 1024,
        };

        let manifest = PackageManifest::new_v2(
            "test".to_string(),
            "1.0.0".to_string(),
            "alpine:latest".to_string(),
            verity,
        );

        assert!(manifest.is_v2());
    }

    #[test]
    fn test_package_create_and_extract() {
        let temp_dir = TempDir::new().unwrap();
        let rootfs = temp_dir.path().join("rootfs");
        let bin_dir = rootfs.join("bin");
        fs::create_dir_all(&bin_dir).unwrap();
        fs::write(bin_dir.join("hello"), "#!/bin/sh\\necho hello").unwrap();

        let config = r#"{"ociVersion": "1.0.2"}"#;
        let manifest = PackageManifest::new(
            "test".to_string(),
            "1.0.0".to_string(),
            "test:latest".to_string(),
        );

        let package_path = temp_dir.path().join("test.tar.gz");
        Package::create(&package_path, &rootfs, config, &manifest).unwrap();

        assert!(package_path.exists());

        let extract_dir = temp_dir.path().join("extracted");
        let extracted_manifest = Package::extract(&package_path, &extract_dir).unwrap();

        assert_eq!(extracted_manifest.name, "test");
        assert!(extract_dir.join("config.json").exists());
        assert!(extract_dir.join("rootfs/bin/hello").exists());
    }

    #[test]
    fn test_package_create_v2_and_extract() {
        let temp_dir = TempDir::new().unwrap();

        let squashfs_path = temp_dir.path().join("rootfs.squashfs");
        let hash_path = temp_dir.path().join("rootfs.squashfs.hash");
        fs::write(&squashfs_path, b"mock squashfs data").unwrap();
        fs::write(&hash_path, b"mock hash data").unwrap();

        let verity = VerityMetadata {
            algorithm: "sha256".to_string(),
            root_hash: "abc123".to_string(),
            salt: None,
            data_block_size: 4096,
            hash_block_size: 4096,
            data_size: 18,
        };

        let config = r#"{"ociVersion": "1.0.2"}"#;
        let manifest = PackageManifest::new_v2(
            "test-v2".to_string(),
            "2.0.0".to_string(),
            "test:latest".to_string(),
            verity,
        );

        let package_path = temp_dir.path().join("test-v2.tar.gz");
        Package::create_v2(&package_path, &squashfs_path, &hash_path, config, &manifest).unwrap();

        assert!(package_path.exists());

        let extract_dir = temp_dir.path().join("extracted");
        let extracted_manifest = Package::extract(&package_path, &extract_dir).unwrap();

        assert_eq!(extracted_manifest.name, "test-v2");
        assert!(extracted_manifest.is_v2());
        assert!(extract_dir.join("config.json").exists());
        assert!(extract_dir.join("rootfs.squashfs").exists());
        assert!(extract_dir.join("rootfs.squashfs.hash").exists());
    }
}
