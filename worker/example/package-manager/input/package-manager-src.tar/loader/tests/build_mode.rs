//! Integration tests for V1 build mode workflow.
//!
//! These tests verify the Docker-like image building workflow:
//! 1. Run container in build mode (--detach with sleep infinity)
//! 2. Execute commands to modify the container
//! 3. Commit changes to a new package
//! 4. Clean up
//!
//! Requires: root, runc

use std::fs;
use std::path::{Path, PathBuf};
use std::process::Command;
use std::thread;
use std::time::Duration;

fn require_root() {
    let output = Command::new("id").arg("-u").output().expect("failed to run id");
    if String::from_utf8_lossy(&output.stdout).trim() != "0" {
        panic!("This test requires root. Run with: sudo -E cargo test ...");
    }
}

fn require_command(cmd: &str) {
    let available = Command::new("which")
        .arg(cmd)
        .output()
        .map(|o| o.status.success())
        .unwrap_or(false);
    if !available {
        panic!("This test requires '{}' to be installed", cmd);
    }
}

fn workspace_paths() -> (PathBuf, PathBuf) {
    let workspace_root = PathBuf::from(env!("CARGO_MANIFEST_DIR"))
        .parent()
        .expect("workspace root")
        .to_path_buf();
    let loader_bin = workspace_root.join("target/debug/loader");
    (workspace_root, loader_bin)
}

fn cleanup_container(loader: &PathBuf, id: &str) {
    // Kill if running
    let _ = Command::new(loader)
        .args(["kill", id])
        .output();
    // Delete
    let _ = Command::new(loader)
        .args(["delete", id, "--force"])
        .output();
}

/// Test: Run container in build mode (--detach)
/// Verifies that container stays running with sleep infinity
#[test]
fn test_build_mode_run_detach() {
    require_root();
    require_command("runc");

    let (workspace_root, loader) = workspace_paths();
    let pkg_path = workspace_root.join("prebuilt/ubuntu-v1.tar.gz");
    let container_id = "test-build-mode-detach";

    // Cleanup any previous run
    cleanup_container(&loader, container_id);

    // Run in build mode
    let status = Command::new(&loader)
        .args([
            "run", container_id,
            "--pkg", pkg_path.to_str().unwrap(),
            "--detach",
        ])
        .status()
        .expect("run loader");

    assert!(status.success(), "loader run --detach should succeed");

    // Wait a moment for container to start
    thread::sleep(Duration::from_millis(500));

    // Verify container is running via runc list
    let output = Command::new("runc")
        .arg("list")
        .output()
        .expect("runc list");
    let stdout = String::from_utf8_lossy(&output.stdout);
    assert!(
        stdout.contains(container_id) && stdout.contains("running"),
        "Container should be running: {}", stdout
    );

    // Cleanup
    cleanup_container(&loader, container_id);
}

/// Test: Execute command in build mode container
#[test]
fn test_build_mode_exec() {
    require_root();
    require_command("runc");

    let (workspace_root, loader) = workspace_paths();
    let pkg_path = workspace_root.join("prebuilt/ubuntu-v1.tar.gz");
    let container_id = "test-build-mode-exec";

    cleanup_container(&loader, container_id);

    // Run in build mode
    let status = Command::new(&loader)
        .args([
            "run", container_id,
            "--pkg", pkg_path.to_str().unwrap(),
            "--detach",
        ])
        .status()
        .expect("run loader");
    assert!(status.success());

    thread::sleep(Duration::from_millis(500));

    // Execute a command
    let output = Command::new(&loader)
        .args(["exec", container_id, "--", "/bin/sh", "-c", "echo hello-from-exec"])
        .output()
        .expect("exec command");

    let stdout = String::from_utf8_lossy(&output.stdout);
    assert!(
        stdout.contains("hello-from-exec"),
        "exec should return output: {}", stdout
    );

    cleanup_container(&loader, container_id);
}

/// Test: Write file in container and verify persistence
#[test]
fn test_build_mode_write_file() {
    require_root();
    require_command("runc");

    let (workspace_root, loader) = workspace_paths();
    let pkg_path = workspace_root.join("prebuilt/ubuntu-v1.tar.gz");
    let container_id = "test-build-mode-write";

    cleanup_container(&loader, container_id);

    // Run in build mode
    let status = Command::new(&loader)
        .args([
            "run", container_id,
            "--pkg", pkg_path.to_str().unwrap(),
            "--detach",
        ])
        .status()
        .expect("run loader");
    assert!(status.success());

    thread::sleep(Duration::from_millis(500));

    // Write a file
    let status = Command::new(&loader)
        .args(["exec", container_id, "--", "/bin/sh", "-c", "echo test-content > /tmp/test-file.txt"])
        .status()
        .expect("write file");
    assert!(status.success());

    // Read it back
    let output = Command::new(&loader)
        .args(["exec", container_id, "--", "cat", "/tmp/test-file.txt"])
        .output()
        .expect("read file");

    let stdout = String::from_utf8_lossy(&output.stdout);
    assert!(
        stdout.contains("test-content"),
        "File content should persist: {}", stdout
    );

    cleanup_container(&loader, container_id);
}

/// Test: Commit container changes to new package
#[test]
fn test_build_mode_commit() {
    require_root();
    require_command("runc");

    let (workspace_root, loader) = workspace_paths();
    let pkg_path = workspace_root.join("prebuilt/ubuntu-v1.tar.gz");
    let container_id = "test-build-mode-commit";
    let output_pkg = workspace_root.join("artifacts/test-committed.tar.gz");

    // Ensure artifacts dir exists
    fs::create_dir_all(workspace_root.join("artifacts")).ok();

    cleanup_container(&loader, container_id);
    let _ = fs::remove_file(&output_pkg);

    // Run in build mode
    let status = Command::new(&loader)
        .args([
            "run", container_id,
            "--pkg", pkg_path.to_str().unwrap(),
            "--detach",
        ])
        .status()
        .expect("run loader");
    assert!(status.success());

    thread::sleep(Duration::from_millis(500));

    // Write a marker file
    let status = Command::new(&loader)
        .args(["exec", container_id, "--", "/bin/sh", "-c", "echo committed-marker > /root/marker.txt"])
        .status()
        .expect("write marker");
    assert!(status.success());

    // Kill container
    let status = Command::new(&loader)
        .args(["kill", container_id])
        .status()
        .expect("kill");
    assert!(status.success());

    // Commit (using positional id)
    let status = Command::new(&loader)
        .args(["commit", container_id, "-o", output_pkg.to_str().unwrap()])
        .status()
        .expect("commit");
    assert!(status.success(), "commit should succeed");

    // Verify package was created
    assert!(output_pkg.exists(), "Committed package should exist");

    // Verify marker file is in the package
    let output = Command::new("tar")
        .args(["-tzf", output_pkg.to_str().unwrap()])
        .output()
        .expect("tar list");
    let stdout = String::from_utf8_lossy(&output.stdout);
    assert!(
        stdout.contains("rootfs/root/marker.txt"),
        "Package should contain marker file: {}", stdout
    );

    // Cleanup
    cleanup_container(&loader, container_id);
    let _ = fs::remove_file(&output_pkg);
}

/// Test: Full workflow - run, exec, commit, run new package
#[test]
fn test_build_mode_full_workflow() {
    require_root();
    require_command("runc");

    let (workspace_root, loader) = workspace_paths();
    let pkg_path = workspace_root.join("prebuilt/ubuntu-v1.tar.gz");
    let container_id = "test-workflow-build";
    let verify_id = "test-workflow-verify";
    let output_pkg = workspace_root.join("artifacts/test-workflow.tar.gz");

    fs::create_dir_all(workspace_root.join("artifacts")).ok();
    cleanup_container(&loader, container_id);
    cleanup_container(&loader, verify_id);
    let _ = fs::remove_file(&output_pkg);

    // Step 1: Run in build mode
    let status = Command::new(&loader)
        .args(["run", container_id, "--pkg", pkg_path.to_str().unwrap(), "--detach"])
        .status()
        .expect("run");
    assert!(status.success());
    thread::sleep(Duration::from_millis(500));

    // Step 2: Modify container
    let status = Command::new(&loader)
        .args(["exec", container_id, "--", "/bin/sh", "-c", "echo workflow-test > /root/workflow.txt"])
        .status()
        .expect("exec");
    assert!(status.success());

    // Step 3: Kill and commit
    Command::new(&loader).args(["kill", container_id]).status().ok();
    let status = Command::new(&loader)
        .args(["commit", container_id, "-o", output_pkg.to_str().unwrap()])
        .status()
        .expect("commit");
    assert!(status.success());

    // Step 4: Delete original
    Command::new(&loader).args(["delete", container_id, "--force"]).status().ok();

    // Step 5: Run new package and verify
    let status = Command::new(&loader)
        .args(["run", verify_id, "--pkg", output_pkg.to_str().unwrap(), "--detach"])
        .status()
        .expect("run new");
    assert!(status.success());
    thread::sleep(Duration::from_millis(500));

    let output = Command::new(&loader)
        .args(["exec", verify_id, "--", "cat", "/root/workflow.txt"])
        .output()
        .expect("verify");
    let stdout = String::from_utf8_lossy(&output.stdout);
    assert!(
        stdout.contains("workflow-test"),
        "New package should contain modifications: {}", stdout
    );

    // Cleanup
    cleanup_container(&loader, verify_id);
    let _ = fs::remove_file(&output_pkg);
}


/// Test: Network access and apt installation
/// Verifies that container can access network and install packages
#[test]
fn test_build_mode_apt_install() {
    require_root();
    require_command("runc");

    let (workspace_root, loader) = workspace_paths();
    let pkg_path = workspace_root.join("prebuilt/ubuntu-v1.tar.gz");
    let container_id = "test-build-mode-apt";

    cleanup_container(&loader, container_id);

    // Run in build mode
    let status = Command::new(&loader)
        .args([
            "run", container_id,
            "--pkg", pkg_path.to_str().unwrap(),
            "--detach",
        ])
        .status()
        .expect("run loader");
    assert!(status.success());

    thread::sleep(Duration::from_millis(500));

    // Test apt update
    let output = Command::new(&loader)
        .args(["exec", container_id, "--", "/bin/sh", "-c", "apt update 2>&1"])
        .output()
        .expect("apt update");
    assert!(
        output.status.success(),
        "apt update should succeed: {}", String::from_utf8_lossy(&output.stdout)
    );

    // Install a small package (file is lightweight)
    let output = Command::new(&loader)
        .args(["exec", container_id, "--", "/bin/sh", "-c", "apt install -y file 2>&1"])
        .output()
        .expect("apt install");
    assert!(output.status.success(), "apt install should succeed: {}", String::from_utf8_lossy(&output.stdout));

    // Verify installed package works
    let output = Command::new(&loader)
        .args(["exec", container_id, "--", "file", "--version"])
        .output()
        .expect("file --version");
    let stdout = String::from_utf8_lossy(&output.stdout);
    assert!(
        stdout.contains("file-") || stdout.contains("magic file"),
        "file command should work: {}", stdout
    );

    cleanup_container(&loader, container_id);
}


/// Test: Volume mount basic read/write
#[test]
fn test_volume_mount_basic() {
    require_root();
    require_command("runc");

    let (workspace_root, loader) = workspace_paths();
    let pkg_path = workspace_root.join("prebuilt/ubuntu-v1.tar.gz");
    let container_id = "test-vol-basic";

    // Setup test volume
    let vol_dir = Path::new("/tmp/test-vol-basic");
    let _ = fs::remove_dir_all(vol_dir);
    fs::create_dir_all(vol_dir).expect("create vol dir");
    fs::write(vol_dir.join("host-file.txt"), "hello from host").expect("write host file");

    cleanup_container(&loader, container_id);

    // Run with volume mount
    let status = Command::new(&loader)
        .args([
            "run", container_id,
            "--pkg", pkg_path.to_str().unwrap(),
            "-v", "/tmp/test-vol-basic:/data",
            "--detach",
        ])
        .status()
        .expect("run loader");
    assert!(status.success());

    thread::sleep(Duration::from_millis(500));

    // Read file from container
    let output = Command::new(&loader)
        .args(["exec", container_id, "--", "cat", "/data/host-file.txt"])
        .output()
        .expect("read file");
    let stdout = String::from_utf8_lossy(&output.stdout);
    assert!(stdout.contains("hello from host"), "Should read host file: {}", stdout);

    // Write file from container
    let status = Command::new(&loader)
        .args(["exec", container_id, "--", "/bin/sh", "-c", "echo container-write > /data/container-file.txt"])
        .status()
        .expect("write file");
    assert!(status.success());

    // Verify on host
    let content = fs::read_to_string(vol_dir.join("container-file.txt")).expect("read container file");
    assert!(content.contains("container-write"), "Host should see container write: {}", content);

    cleanup_container(&loader, container_id);
    let _ = fs::remove_dir_all(vol_dir);
}

/// Test: Volume mount read-only
#[test]
fn test_volume_mount_readonly() {
    require_root();
    require_command("runc");

    let (workspace_root, loader) = workspace_paths();
    let pkg_path = workspace_root.join("prebuilt/ubuntu-v1.tar.gz");
    let container_id = "test-vol-ro";

    // Setup test volume
    let vol_dir = Path::new("/tmp/test-vol-ro");
    let _ = fs::remove_dir_all(vol_dir);
    fs::create_dir_all(vol_dir).expect("create vol dir");
    fs::write(vol_dir.join("readonly.txt"), "read only content").expect("write file");

    cleanup_container(&loader, container_id);

    // Run with read-only volume
    let status = Command::new(&loader)
        .args([
            "run", container_id,
            "--pkg", pkg_path.to_str().unwrap(),
            "-v", "/tmp/test-vol-ro:/data:ro",
            "--detach",
        ])
        .status()
        .expect("run loader");
    assert!(status.success());

    thread::sleep(Duration::from_millis(500));

    // Read should work
    let output = Command::new(&loader)
        .args(["exec", container_id, "--", "cat", "/data/readonly.txt"])
        .output()
        .expect("read file");
    assert!(String::from_utf8_lossy(&output.stdout).contains("read only content"));

    // Write should fail
    let output = Command::new(&loader)
        .args(["exec", container_id, "--", "/bin/sh", "-c", "echo test > /data/new.txt"])
        .output()
        .expect("write attempt");
    assert!(!output.status.success(), "Write to read-only volume should fail");

    cleanup_container(&loader, container_id);
    let _ = fs::remove_dir_all(vol_dir);
}
