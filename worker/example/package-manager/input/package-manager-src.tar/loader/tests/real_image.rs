use std::fs;
use std::path::PathBuf;
use std::process::Command;

/// Require running as root, panic otherwise
fn require_root() {
    let output = Command::new("id").arg("-u").output().expect("failed to run id");
    if String::from_utf8_lossy(&output.stdout).trim() != "0" {
        panic!("This test requires root. Run with: sudo -E cargo test ...");
    }
}

/// Require a command to be available, panic otherwise
fn require_command(cmd: &str) {
    let available = Command::new("which")
        .arg(cmd)
        .output()
        .map(|o| o.status.success())
        .unwrap_or(false);
    if !available {
        panic!("This test requires '{}' to be installed", cmd);
    }
}

fn workspace_paths() -> (PathBuf, PathBuf, PathBuf) {
    let workspace_root = PathBuf::from(env!("CARGO_MANIFEST_DIR"))
        .parent()
        .expect("workspace root")
        .to_path_buf();
    let builder_bin = workspace_root.join("target/debug/builder");
    let loader_bin = workspace_root.join("target/debug/loader");
    (workspace_root, builder_bin, loader_bin)
}

#[test]
fn build_and_run_v1_package() {
    // Prerequisites: root + runc
    require_root();
    require_command("runc");

    let (workspace_root, builder_bin, loader_bin) = workspace_paths();
    let artifacts_dir = workspace_root.join("artifacts");
    fs::create_dir_all(&artifacts_dir).expect("create artifacts dir");

    let pkg_path = artifacts_dir.join("alpine-v1.tar.gz");
    let container_id = "test-alpine-v1";

    // Build V1 package (--format-version 1 is default)
    let status = Command::new(&builder_bin)
        .args([
            "build",
            "alpine:latest",
            "-o",
            pkg_path.to_str().unwrap(),
            "--format-version", "1",
        ])
        .status()
        .expect("run builder");
    assert!(status.success(), "builder failed for V1");

    // Run V1 package
    let output = Command::new(&loader_bin)
        .args(["run", pkg_path.to_str().unwrap(), "--id", container_id, "--cmd", "echo hello-from-container"])
        .output()
        .expect("run loader");

    let stdout = String::from_utf8_lossy(&output.stdout);
    let stderr = String::from_utf8_lossy(&output.stderr);

    assert!(output.status.success(), "loader failed: {}", stderr);
    assert!(
        stdout.contains("hello-from-container"),
        "V1 unexpected output: {}\nstderr: {}",
        stdout,
        stderr
    );

    // Verify it's V1 by checking stderr
    assert!(
        stderr.contains("Running V1 package"),
        "Should be V1 package: {}",
        stderr
    );
}

#[test]
fn build_and_run_v2_package() {
    // Prerequisites: root + runc + veritysetup + mksquashfs
    require_root();
    require_command("runc");
    require_command("veritysetup");
    require_command("mksquashfs");

    let (workspace_root, builder_bin, loader_bin) = workspace_paths();
    let artifacts_dir = workspace_root.join("artifacts");
    fs::create_dir_all(&artifacts_dir).expect("create artifacts dir");

    let pkg_path = artifacts_dir.join("ubuntu-v2.tar.gz");
    let container_id = "test-ubuntu-v2";

    // Build V2 package
    let status = Command::new(&builder_bin)
        .args([
            "build",
            "ubuntu:latest",
            "-o",
            pkg_path.to_str().unwrap(),
            "--format-version", "2",
        ])
        .status()
        .expect("run builder");
    assert!(status.success(), "builder failed for V2");

    // Run V2 package (--cmd not supported for V2 - immutable)
    let output = Command::new(&loader_bin)
        .args(["run", pkg_path.to_str().unwrap(), "--id", container_id])
        .output()
        .expect("run loader");

    let stderr = String::from_utf8_lossy(&output.stderr);

    assert!(output.status.success(), "loader failed: {}", stderr);

    // Verify V2 package was used with dm-verity
    assert!(
        stderr.contains("Running V2 package"),
        "Should be V2 package: {}",
        stderr
    );
    assert!(
        stderr.contains("verity device") || stderr.contains("Opening verity"),
        "Should show verity setup: {}",
        stderr
    );
}
