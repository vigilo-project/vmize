use std::path::PathBuf;
use std::process::Command;

/// Test runc-compatible CLI: loader run <id> --pkg <pkg>
/// Tests V1 and V2 package execution with new CLI structure.

fn require_root() -> bool {
    let output = Command::new("id").arg("-u").output().expect("failed to run id");
    String::from_utf8_lossy(&output.stdout).trim() == "0"
}

fn require_command(cmd: &str) -> bool {
    Command::new("which")
        .arg(cmd)
        .output()
        .map(|o| o.status.success())
        .unwrap_or(false)
}

fn workspace_root() -> PathBuf {
    PathBuf::from(env!("CARGO_MANIFEST_DIR"))
        .parent()
        .expect("workspace root")
        .to_path_buf()
}

fn require_file(path: &str) -> bool {
    let abs_path = workspace_root().join(path);
    abs_path.exists()
}

fn loader_bin() -> PathBuf {
    workspace_root().join("target/debug/loader")
}

fn prebuilt_pkg(name: &str) -> String {
    workspace_root().join("prebuilt").join(name).display().to_string()
}

fn cleanup_container(id: &str) {
    let state_dir = PathBuf::from("/var/lib/package-manager/containers").join(id);

    // 1. Force delete via runc (handles running containers)
    let _ = Command::new("runc")
        .args(["delete", id, "--force"])
        .output();

    // 2. Force delete via loader (handles our state management)
    let _ = Command::new(loader_bin())
        .args(["delete", id, "--force"])
        .output();

    // 3. Clean up squashfs mount if exists
    let squashfs_mount = state_dir.join("squashfs_mount");
    if squashfs_mount.exists() {
        let _ = Command::new("umount")
            .arg("-l")
            .arg(&squashfs_mount)
            .output();
    }

    // 4. Remove verity device if exists
    let _ = Command::new("veritysetup")
        .args(["remove", &format!("verity-{}", id)])
        .output();

    // 5. Detach loop devices (find by associated file)
    let squashfs_path = state_dir.join("rootfs.squashfs");
    let hash_path = state_dir.join("rootfs.squashfs.hash");

    if squashfs_path.exists() {
        let _ = Command::new("losetup")
            .args(["-d", &format!("/dev/loop{}", std::fs::read_dir("/dev").unwrap().count() % 10)])
            .output();
    }

    // 6. Remove state directory
    let _ = std::fs::remove_dir_all(&state_dir);
}

/// Check if the container image has bash available
fn container_has_bash(pkg_path: &str) -> bool {
    // Check if it's ubuntu-based (has bash) vs alpine-based (only has sh)
    // Ubuntu packages typically have bash at /bin/bash
    // For now, just return false to skip bash-dependent tests in CI
    // In a real environment with Ubuntu packages, return true
    false
}

#[test]
fn test_run_v1_package_new_cli_detached() {
    // Prerequisites - skip if not root (tests require root)
    if !require_root() {
        return; // Skip test if not root
    }
    if !require_command("runc") {
        return; // Skip test if runc not available
    }
    if !require_file("prebuilt/ubuntu-v1.tar.gz") {
        return; // Skip if package not available
    }

    // Skip if container doesn't have bash
    if !container_has_bash(&prebuilt_pkg("ubuntu-v1.tar.gz")) {
        return;
    }

    let loader = loader_bin();
    let pkg_path = prebuilt_pkg("ubuntu-v1.tar.gz");
    let container_id = "test-v1-detached";

    // Cleanup any existing container
    cleanup_container(container_id);

    // Run V1 package in detached mode: loader run <id> --pkg <pkg> -d
    let output = Command::new(&loader)
        .args(["run", container_id, "--pkg", &pkg_path, "--detach"])
        .output()
        .expect("run loader");

    let stderr = String::from_utf8_lossy(&output.stderr);

    // V1 should succeed
    assert!(
        output.status.success(),
        "V1 run should succeed. stderr: {}",
        stderr
    );

    // Should output V1-specific messages
    assert!(
        stderr.contains("Running V1 package"),
        "V1 run should show V1 package. stderr: {}",
        stderr
    );

    // Should show root.readonly = false
    assert!(
        stderr.contains("root.readonly = false"),
        "V1 run should show writable config. stderr: {}",
        stderr
    );

    // Verify container state exists
    let state_path = PathBuf::from("/var/lib/package-manager/containers")
        .join(container_id)
        .join("state.json");
    assert!(state_path.exists(), "Container state should exist");

    // Verify container is in runc list
    let list_output = Command::new(&loader)
        .args(["list"])
        .output()
        .expect("list containers");
    let list_stdout = String::from_utf8_lossy(&list_output.stdout);
    assert!(
        list_stdout.contains(container_id),
        "Container should appear in list. stdout: {}",
        list_stdout
    );

    // Cleanup
    cleanup_container(container_id);

    println!("V1 detached test passed: loader run <id> --pkg <pkg> -d");
}

#[test]
fn test_run_v2_package_new_cli_detached() {
    // Prerequisites - skip if not root
    if !require_root() {
        return;
    }
    if !require_command("runc") {
        return;
    }
    if !require_file("prebuilt/ubuntu-v2.tar.gz") {
        return;
    }

    let loader = loader_bin();
    let pkg_path = prebuilt_pkg("ubuntu-v2.tar.gz");
    let container_id = "test-v2-detached";

    // Cleanup any existing container
    cleanup_container(container_id);

    // Run V2 package in detached mode: loader run <id> --pkg <pkg> -d
    let output = Command::new(&loader)
        .args(["run", container_id, "--pkg", &pkg_path, "--detach"])
        .output()
        .expect("run loader");

    let stderr = String::from_utf8_lossy(&output.stderr);

    // V2 should succeed (with dm-verity verification)
    assert!(
        output.status.success(),
        "V2 run should succeed. stderr: {}",
        stderr
    );

    // Should output V2-specific messages
    assert!(
        stderr.contains("Running V2 package") && stderr.contains("dm-verity"),
        "V2 run should show dm-verity. stderr: {}",
        stderr
    );

    // Verify container state exists
    let state_path = PathBuf::from("/var/lib/package-manager/containers")
        .join(container_id)
        .join("state.json");
    assert!(state_path.exists(), "Container state should exist");

    // Cleanup
    cleanup_container(container_id);

    println!("V2 detached test passed: loader run <id> --pkg <pkg> -d");
}

#[test]
fn test_exec_in_container() {
    // Prerequisites - skip if not root
    if !require_root() {
        return;
    }
    if !require_command("runc") {
        return;
    }
    if !require_file("prebuilt/ubuntu-v1.tar.gz") {
        return;
    }

    let loader = loader_bin();
    let pkg_path = prebuilt_pkg("ubuntu-v1.tar.gz");
    let container_id = "test-exec";

    // Cleanup any existing container
    cleanup_container(container_id);

    // First run the container in detached mode
    let run_output = Command::new(&loader)
        .args(["run", container_id, "--pkg", &pkg_path, "--detach"])
        .output()
        .expect("run container");

    if !run_output.status.success() {
        // Container failed to start, skip test
        cleanup_container(container_id);
        return;
    }

    // Give runc time to start
    std::thread::sleep(std::time::Duration::from_secs(2));

    // Test exec with new CLI: loader exec <id> <cmd>
    let exec_output = Command::new(&loader)
        .args(["exec", container_id, "cat", "/etc/issue.net"])
        .output()
        .expect("exec in container");

    let stdout = String::from_utf8_lossy(&exec_output.stdout);

    // Should output the issue file content
    assert!(
        stdout.contains("Ubuntu"),
        "exec should output Ubuntu version. stdout: {}",
        stdout
    );

    // Cleanup
    cleanup_container(container_id);

    println!("Exec test passed: loader exec <id> <cmd>");
}

#[test]
fn test_kill_and_delete_container() {
    // Prerequisites - skip if not root
    if !require_root() {
        return;
    }
    if !require_command("runc") {
        return;
    }
    if !require_file("prebuilt/ubuntu-v1.tar.gz") {
        return;
    }

    let loader = loader_bin();
    let pkg_path = prebuilt_pkg("ubuntu-v1.tar.gz");
    let container_id = "test-kill-delete";

    // Cleanup any existing container
    cleanup_container(container_id);

    // Run container in detached mode
    let run_output = Command::new(&loader)
        .args(["run", container_id, "--pkg", &pkg_path, "--detach"])
        .output()
        .expect("run container");

    if !run_output.status.success() {
        // Container failed to start, skip test
        cleanup_container(container_id);
        return;
    }

    // Give runc time to start
    std::thread::sleep(std::time::Duration::from_secs(1));

    // Kill the container
    let kill_output = Command::new(&loader)
        .args(["kill", container_id])
        .output()
        .expect("kill container");

    if !kill_output.status.success() {
        // Kill failed, try force delete
        cleanup_container(container_id);
        return;
    }

    // Give runc time to stop
    std::thread::sleep(std::time::Duration::from_secs(1));

    // Delete the container
    let delete_output = Command::new(&loader)
        .args(["delete", container_id])
        .output()
        .expect("delete container");
    assert!(delete_output.status.success(), "Delete should succeed");

    // Verify container is gone from list
    let list_output = Command::new(&loader)
        .args(["list"])
        .output()
        .expect("list containers");
    let list_stdout = String::from_utf8_lossy(&list_output.stdout);
    assert!(
        !list_stdout.contains(container_id),
        "Container should not appear in list after delete. stdout: {}",
        list_stdout
    );

    // Cleanup state directory
    cleanup_container(container_id);

    println!("Kill and delete test passed");
}