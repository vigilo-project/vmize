use std::path::PathBuf;
use std::process::Command;

fn require_root() -> bool {
    let output = Command::new("id").arg("-u").output().expect("failed to run id");
    String::from_utf8_lossy(&output.stdout).trim() == "0"
}

fn require_command(cmd: &str) -> bool {
    Command::new("which")
        .arg(cmd)
        .output()
        .map(|o| o.status.success())
        .unwrap_or(false)
}

fn workspace_root() -> PathBuf {
    PathBuf::from(env!("CARGO_MANIFEST_DIR"))
        .parent()
        .expect("workspace root")
        .to_path_buf()
}

fn require_file(path: &str) -> bool {
    workspace_root().join(path).exists()
}

fn loader_bin() -> PathBuf {
    workspace_root().join("target/debug/loader")
}

fn prebuilt_pkg(name: &str) -> String {
    workspace_root()
        .join("prebuilt")
        .join(name)
        .display()
        .to_string()
}

fn cleanup_container(id: &str) {
    let state_dir = PathBuf::from("/var/lib/package-manager/containers").join(id);

    let _ = Command::new("runc")
        .args(["delete", id, "--force"])
        .output();

    let _ = Command::new(loader_bin())
        .args(["delete", id, "--force"])
        .output();

    let squashfs_mount = state_dir.join("squashfs_mount");
    if squashfs_mount.exists() {
        let _ = Command::new("umount")
            .arg("-l")
            .arg(&squashfs_mount)
            .output();
    }

    let _ = Command::new("veritysetup")
        .args(["remove", &format!("verity-{}", id)])
        .output();

    let _ = std::fs::remove_dir_all(&state_dir);
}

#[test]
fn test_run_vmize_package_detached() {
    if !require_root() || !require_command("runc") || !require_file("prebuilt/test.tar") {
        return;
    }

    let loader = loader_bin();
    let pkg_path = prebuilt_pkg("test.tar");
    let container_id = "test-vmize-detached";

    cleanup_container(container_id);

    let output = Command::new(&loader)
        .args(["run", container_id, "--pkg", &pkg_path, "--detach"])
        .output()
        .expect("run loader");

    let stderr = String::from_utf8_lossy(&output.stderr);
    assert!(
        output.status.success(),
        "run should succeed. stderr: {}",
        stderr
    );

    let state_path = PathBuf::from("/var/lib/package-manager/containers")
        .join(container_id)
        .join("state.json");
    assert!(state_path.exists(), "Container state should exist");

    cleanup_container(container_id);
}

#[test]
fn test_kill_and_delete_container() {
    if !require_root() || !require_command("runc") || !require_file("prebuilt/test.tar") {
        return;
    }

    let loader = loader_bin();
    let pkg_path = prebuilt_pkg("test.tar");
    let container_id = "test-kill-delete";

    cleanup_container(container_id);

    let run_output = Command::new(&loader)
        .args(["run", container_id, "--pkg", &pkg_path, "--detach"])
        .output()
        .expect("run container");

    if !run_output.status.success() {
        cleanup_container(container_id);
        return;
    }

    std::thread::sleep(std::time::Duration::from_secs(1));

    let kill_output = Command::new(&loader)
        .args(["kill", container_id])
        .output()
        .expect("kill container");

    if !kill_output.status.success() {
        cleanup_container(container_id);
        return;
    }

    std::thread::sleep(std::time::Duration::from_secs(1));

    let delete_output = Command::new(&loader)
        .args(["delete", container_id])
        .output()
        .expect("delete container");
    assert!(delete_output.status.success(), "Delete should succeed");

    let list_output = Command::new(&loader)
        .args(["list"])
        .output()
        .expect("list containers");
    let list_stdout = String::from_utf8_lossy(&list_output.stdout);
    assert!(
        !list_stdout.contains(container_id),
        "Container should not appear in list after delete. stdout: {}",
        list_stdout
    );

    cleanup_container(container_id);
}
