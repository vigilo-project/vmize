use std::fs;

use builder::build_from_rootfs;
use format::PackageManifest;
use loader::extract_package;
use tempfile::TempDir;

#[test]
fn builder_creates_package_loader_extracts() {
    let temp_dir = TempDir::new().expect("tempdir");
    let rootfs_dir = temp_dir.path().join("rootfs");
    let bin_dir = rootfs_dir.join("bin");
    fs::create_dir_all(&bin_dir).expect("create bin dir");
    fs::write(bin_dir.join("hello"), "#!/bin/sh
echo hello
").expect("write hello");

    let package_path = temp_dir.path().join("pkg.tar.gz");
    let manifest = PackageManifest::new(
        "test-pkg".to_string(),
        "0.1.0".to_string(),
        "local/rootfs".to_string(),
    );

    build_from_rootfs(&rootfs_dir, &package_path, &manifest, None, false).expect("build package");

    let (extracted_manifest, _temp_dir) =
        extract_package(&package_path).expect("extract package");

    assert_eq!(extracted_manifest.name, "test-pkg");
    assert_eq!(extracted_manifest.version, "0.1.0");
    assert_eq!(extracted_manifest.image_ref, "local/rootfs");
}
