//! Container state management for persistent containers.
//!
//! Containers store their state at:
//! `/var/lib/package-manager/containers/<container-id>/`

use chrono::{DateTime, Utc};
use serde::{Deserialize, Serialize};
use std::fs;
use std::path::PathBuf;

use crate::LoaderError;

/// Base directory for all container state.
pub const CONTAINER_DIR: &str = "/var/lib/package-manager/containers";

/// Container state metadata stored in state.json.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ContainerState {
    pub id: String,
    pub created_at: DateTime<Utc>,
    pub source_package: PathBuf,
    pub status: ContainerStatus,
    pub writable: bool,
    pub rootfs_type: RootfsType,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub enum ContainerStatus {
    Running,
    Stopped,
    Deleted,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub enum RootfsType {
    Directory,
    Squashfs,
}

/// Get the state file path for a container ID.
pub fn state_file_path(id: &str) -> PathBuf {
    PathBuf::from(CONTAINER_DIR).join(id).join("state.json")
}

/// Get the container rootfs path.
pub fn rootfs_path(id: &str) -> PathBuf {
    PathBuf::from(CONTAINER_DIR).join(id).join("rootfs")
}

/// Get the bundle directory path (contains config.json for runc).
pub fn bundle_path(id: &str) -> PathBuf {
    PathBuf::from(CONTAINER_DIR).join(id)
}

/// Save container state to state.json.
pub fn save_state(state: &ContainerState) -> Result<(), LoaderError> {
    let state_path = state_file_path(&state.id);
    if let Some(parent) = state_path.parent() {
        fs::create_dir_all(parent)?;
    }
    let json = serde_json::to_string_pretty(state)?;
    fs::write(&state_path, json)?;
    Ok(())
}

/// Load container state from state.json.
pub fn load_state(id: &str) -> Result<Option<ContainerState>, LoaderError> {
    let state_path = state_file_path(id);
    if !state_path.exists() {
        return Ok(None);
    }
    let json = fs::read_to_string(&state_path)?;
    let state: ContainerState = serde_json::from_str(&json)?;
    Ok(Some(state))
}

/// Check if a container state exists.
pub fn state_exists(id: &str) -> bool {
    state_file_path(id).exists()
}

/// Delete container state directory.
pub fn remove_state(id: &str) -> Result<(), LoaderError> {
    let container_dir = PathBuf::from(CONTAINER_DIR).join(id);
    if container_dir.exists() {
        fs::remove_dir_all(&container_dir)?;
    }
    Ok(())
}

/// List all container IDs.
pub fn list_container_ids() -> Result<Vec<String>, LoaderError> {
    let container_dir = PathBuf::from(CONTAINER_DIR);
    if !container_dir.exists() {
        return Ok(Vec::new());
    }
    let mut ids = Vec::new();
    for entry in fs::read_dir(&container_dir)? {
        let entry = entry?;
        if entry.path().is_dir() && entry.path().join("state.json").exists() {
            if let Some(name) = entry.file_name().to_str() {
                ids.push(name.to_string());
            }
        }
    }
    Ok(ids)
}

/// Format container state for display.
pub fn format_container_state(state: &ContainerState) -> String {
    format!(
        "{}  {:<20}  {:<15}  {}",
        state.id,
        state.source_package.file_name().unwrap_or_default().to_string_lossy(),
        format!("{:?}", state.status).to_lowercase(),
        if state.writable { "yes" } else { "no" }
    )
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_container_state_serde() {
        let state = ContainerState {
            id: "test-container".to_string(),
            created_at: Utc::now(),
            source_package: PathBuf::from("/path/to/package.tar.gz"),
            status: ContainerStatus::Running,
            writable: true,
            rootfs_type: RootfsType::Directory,
        };

        let json = serde_json::to_string_pretty(&state).unwrap();
        let decoded: ContainerState = serde_json::from_str(&json).unwrap();

        assert_eq!(state.id, decoded.id);
        assert_eq!(state.writable, decoded.writable);
        assert!(matches!(decoded.status, ContainerStatus::Running));
    }

    #[test]
    fn test_container_state_path() {
        assert_eq!(
            state_file_path("my-container"),
            PathBuf::from("/var/lib/package-manager/containers/my-container/state.json")
        );
        assert_eq!(
            rootfs_path("my-container"),
            PathBuf::from("/var/lib/package-manager/containers/my-container/rootfs")
        );
    }
}
