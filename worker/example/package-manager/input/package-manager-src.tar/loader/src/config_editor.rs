//! OCI config.json manipulation helpers.
//!
//! All functions in this module modify the OCI runtime config at
//! `<bundle_dir>/config.json`. The common read-modify-write cycle
//! is handled by [`with_config`].

use std::fs;
use std::path::Path;

use crate::LoaderError;

/// Read config.json, apply a mutation closure, then write it back.
///
/// This eliminates the repetitive read → parse → modify → serialize → write
/// pattern that was duplicated across every config manipulation function.
fn with_config<F>(bundle_dir: &Path, f: F) -> Result<(), LoaderError>
where
    F: FnOnce(&mut serde_json::Value),
{
    let config_path = bundle_dir.join("config.json");
    let content = fs::read_to_string(&config_path)?;
    let mut config: serde_json::Value = serde_json::from_str(&content)?;

    f(&mut config);

    let updated = serde_json::to_string_pretty(&config)?;
    fs::write(&config_path, updated)?;
    Ok(())
}

/// Disable TTY in config.json for detached mode.
pub fn disable_tty(bundle_dir: &Path) -> Result<(), LoaderError> {
    with_config(bundle_dir, |config| {
        config["tty"] = serde_json::Value::Bool(false);
        if let Some(process) = config.get_mut("process") {
            process["terminal"] = serde_json::Value::Bool(false);
        }
    })
}

/// Configure container for build mode (sleep infinity).
///
/// Disables TTY and sets the process args to `["/bin/sleep", "infinity"]`,
/// keeping the container running indefinitely for exec commands.
pub fn enable_build_mode(bundle_dir: &Path) -> Result<(), LoaderError> {
    with_config(bundle_dir, |config| {
        config["tty"] = serde_json::Value::Bool(false);
        if let Some(process) = config.get_mut("process") {
            process["terminal"] = serde_json::Value::Bool(false);
            process["args"] = serde_json::json!(["/bin/sleep", "infinity"]);
        }
    })?;
    eprintln!("Build mode enabled (sleep infinity)");
    Ok(())
}

/// Update config.json to point rootfs to the given mount path.
pub fn update_config_rootfs(bundle_dir: &Path, mount_path: &Path) -> Result<(), LoaderError> {
    with_config(bundle_dir, |config| {
        if let Some(root) = config.get_mut("root") {
            if let Some(path) = root.get_mut("path") {
                *path = serde_json::Value::String(mount_path.to_string_lossy().into_owned());
            }
        }
    })
}

/// Update config.json for writable rootfs:
/// - `root.readonly = false`
/// - Remove network namespace (host network access)
/// - Add full capabilities for package management
pub fn update_config_writable(bundle_dir: &Path) -> Result<(), LoaderError> {
    with_config(bundle_dir, |config| {
        // Set root.readonly = false
        if let Some(root) = config.get_mut("root") {
            root["readonly"] = serde_json::Value::Bool(false);
        }

        // Remove network namespace for host network access
        if let Some(linux) = config.get_mut("linux") {
            if let Some(namespaces) = linux.get_mut("namespaces") {
                if let Some(arr) = namespaces.as_array_mut() {
                    arr.retain(|ns| {
                        ns.get("type").and_then(|t| t.as_str()) != Some("network")
                    });
                }
            }
        }

        // Add capabilities needed for package management (apt, etc.)
        let caps = serde_json::json!([
            "CAP_AUDIT_WRITE",
            "CAP_NET_BIND_SERVICE",
            "CAP_KILL",
            "CAP_SETUID",
            "CAP_SETGID",
            "CAP_CHOWN",
            "CAP_DAC_OVERRIDE",
            "CAP_FOWNER",
            "CAP_SYS_CHROOT",
            "CAP_NET_RAW"
        ]);

        if let Some(process) = config.get_mut("process") {
            if let Some(capabilities) = process.get_mut("capabilities") {
                for key in ["ambient", "bounding", "effective", "inheritable", "permitted"] {
                    capabilities[key] = caps.clone();
                }
            }
        }
    })?;
    eprintln!("Config updated: writable rootfs, host network, full capabilities");
    Ok(())
}

/// Update config.json for interactive mode (enable TTY and set default shell).
pub fn enable_interactive(bundle_path: &Path) -> Result<(), LoaderError> {
    // Determine shell: check in container's rootfs
    let rootfs_path = bundle_path.join("rootfs");
    let shell = detect_shell(&rootfs_path);

    with_config(bundle_path, |config| {
        config["tty"] = serde_json::Value::Bool(true);

        if let Some(process) = config.get_mut("process") {
            process["terminal"] = serde_json::Value::Bool(true);

            // Use appropriate shell
            if let Some(args) = process.get_mut("args") {
                if args.is_array() {
                    args[0] = serde_json::Value::String(shell.to_string());
                }
            }

            // Ensure TERM env var is set
            if let Some(env) = process.get_mut("env") {
                if let Some(arr) = env.as_array() {
                    let term_present = arr
                        .iter()
                        .any(|e| e.as_str().is_some_and(|s| s.starts_with("TERM=")));
                    if !term_present {
                        if let Some(arr) = env.as_array_mut() {
                            arr.push(serde_json::Value::String("TERM=xterm".to_string()));
                        }
                    }
                }
            }
        }

        // Set default command at root level if not already set
        if !config["cmd"].is_array() {
            config["cmd"] = serde_json::json!([shell, "-c"]);
        }

        // Set default working directory
        if config["working_dir"].is_null() || !config["working_dir"].is_string() {
            config["working_dir"] = serde_json::Value::String("/".to_string());
        }
    })?;
    eprintln!("Enabled interactive mode (TTY + {})", shell);
    Ok(())
}

/// Detect the best available shell in a rootfs.
fn detect_shell(rootfs_path: &Path) -> &'static str {
    let has = |rel: &str| rootfs_path.join(rel).exists();

    if has("usr/bin/bash") || has("bin/bash") {
        "bash"
    } else {
        "sh"
    }
}

// ── Volume mount support ────────────────────────────────────────────────

/// Parsed volume mount specification.
struct VolumeMount {
    source: String,
    destination: String,
    readonly: bool,
}

/// Parse a volume specification: `host:container` or `host:container:ro`.
fn parse_volume(spec: &str) -> Result<VolumeMount, LoaderError> {
    let parts: Vec<&str> = spec.split(':').collect();

    match parts.len() {
        2 => Ok(VolumeMount {
            source: parts[0].to_string(),
            destination: parts[1].to_string(),
            readonly: false,
        }),
        3 => Ok(VolumeMount {
            source: parts[0].to_string(),
            destination: parts[1].to_string(),
            readonly: parts[2] == "ro",
        }),
        _ => Err(LoaderError::ExecutionFailed(format!(
            "Invalid volume format: {}. Expected host:container[:ro]",
            spec
        ))),
    }
}

/// Add volume bind-mounts to config.json.
pub fn add_volume_mounts(bundle_dir: &Path, volumes: &[String]) -> Result<(), LoaderError> {
    if volumes.is_empty() {
        return Ok(());
    }

    // Parse and validate all volume specs before mutating config
    let mounts: Vec<VolumeMount> = volumes
        .iter()
        .map(|v| parse_volume(v))
        .collect::<Result<Vec<_>, _>>()?;

    for vol in &mounts {
        let source_path = Path::new(&vol.source);
        if !source_path.exists() {
            return Err(LoaderError::ExecutionFailed(format!(
                "Volume source path does not exist: {}",
                vol.source
            )));
        }
    }

    with_config(bundle_dir, |config| {
        if config.get("mounts").is_none() {
            config["mounts"] = serde_json::json!([]);
        }

        if let Some(mount_array) = config["mounts"].as_array_mut() {
            for vol in &mounts {
                let options = if vol.readonly {
                    vec!["bind", "ro"]
                } else {
                    vec!["bind", "rw"]
                };

                mount_array.push(serde_json::json!({
                    "destination": vol.destination,
                    "type": "bind",
                    "source": vol.source,
                    "options": options
                }));

                eprintln!(
                    "Volume: {} -> {}{}",
                    vol.source,
                    vol.destination,
                    if vol.readonly { " (ro)" } else { "" }
                );
            }
        }
    })
}

/// Setup container filesystem for package management.
///
/// Copies host DNS config and ensures `/tmp` exists with proper permissions.
pub fn setup_container_fs(bundle_dir: &Path) -> Result<(), LoaderError> {
    let resolv_src = Path::new("/etc/resolv.conf");
    let resolv_dst = bundle_dir.join("rootfs/etc/resolv.conf");
    if resolv_src.exists() {
        if let Some(parent) = resolv_dst.parent() {
            fs::create_dir_all(parent)?;
        }
        fs::copy(resolv_src, &resolv_dst)?;
        eprintln!("Copied /etc/resolv.conf for DNS");
    }

    let tmp_dir = bundle_dir.join("rootfs/tmp");
    fs::create_dir_all(&tmp_dir)?;
    #[cfg(unix)]
    {
        use std::os::unix::fs::PermissionsExt;
        fs::set_permissions(&tmp_dir, fs::Permissions::from_mode(0o1777))?;
    }

    Ok(())
}
