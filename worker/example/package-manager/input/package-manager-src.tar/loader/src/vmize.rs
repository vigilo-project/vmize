use std::collections::HashSet;
use std::fs::{self, File};
use std::path::{Path, PathBuf};

use tar::Archive;

use crate::LoaderError;

const REQUIRED_VMIZE_FILES: [&str; 4] = [
    "rootfs.squashfs",
    "rootfs.verity",
    "rootfs.root_hash",
    "config.json",
];

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct RwExecViolation {
    pub destination: String,
    pub options: Vec<String>,
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct RwExecCheckResult {
    pub total_rw_mounts: usize,
    pub violations: Vec<RwExecViolation>,
}

pub fn extract_vmize_package(package_path: &Path, output_dir: &Path) -> Result<(), LoaderError> {
    fs::create_dir_all(output_dir)?;

    let file = File::open(package_path)?;
    let mut archive = Archive::new(file);
    let mut seen: HashSet<String> = HashSet::new();

    for entry in archive.entries()? {
        let mut entry = entry?;
        let raw_path = entry.path()?;
        let normalized = normalize_path(&raw_path)?;

        if REQUIRED_VMIZE_FILES.contains(&normalized.as_str()) {
            seen.insert(normalized.clone());
        }

        let dest_path = output_dir.join(&normalized);
        if let Some(parent) = dest_path.parent() {
            fs::create_dir_all(parent)?;
        }
        entry.unpack(&dest_path)?;
    }

    let missing: Vec<&str> = REQUIRED_VMIZE_FILES
        .iter()
        .copied()
        .filter(|f| !seen.contains(*f))
        .collect();
    if !missing.is_empty() {
        return Err(LoaderError::ExecutionFailed(format!(
            "vmize package is missing required files: {}",
            missing.join(", ")
        )));
    }

    Ok(())
}

pub fn read_root_hash(root_hash_path: &Path) -> Result<String, LoaderError> {
    let root_hash = fs::read_to_string(root_hash_path)?
        .trim()
        .to_ascii_lowercase();

    if root_hash.len() != 64 || !root_hash.chars().all(|c| c.is_ascii_hexdigit()) {
        return Err(LoaderError::ExecutionFailed(format!(
            "invalid root hash format in {}: expected 64 hex chars",
            root_hash_path.display()
        )));
    }

    Ok(root_hash)
}

pub fn setup_vmize_runtime(config_path: &Path, container_dir: &Path) -> Result<(), LoaderError> {
    let runtime_dir = container_dir.join("runtime");
    let models_dir = runtime_dir.join("models");
    let sockets_dir = runtime_dir.join("sockets");

    fs::create_dir_all(&models_dir)?;
    fs::create_dir_all(&sockets_dir)?;

    #[cfg(unix)]
    {
        use std::os::unix::fs::PermissionsExt;
        fs::set_permissions(&sockets_dir, fs::Permissions::from_mode(0o777))?;
    }

    let packaged_model = container_dir.join("model.gguf");
    if packaged_model.exists() {
        fs::copy(&packaged_model, models_dir.join("model.gguf"))?;
    }

    let mut config: serde_json::Value = serde_json::from_str(&fs::read_to_string(config_path)?)?;
    let mounts = ensure_mount_array(&mut config)?;

    upsert_mount(
        mounts,
        "/models",
        models_dir,
        vec!["rbind".to_string(), "ro".to_string()],
    );
    upsert_mount(
        mounts,
        "/sockets",
        sockets_dir,
        vec!["rbind".to_string(), "rw".to_string()],
    );

    fs::write(config_path, serde_json::to_string_pretty(&config)?)?;
    Ok(())
}

pub fn validate_rw_noexec(config_path: &Path) -> Result<RwExecCheckResult, LoaderError> {
    let config: serde_json::Value = serde_json::from_str(&fs::read_to_string(config_path)?)?;

    let mut total_rw_mounts = 0usize;
    let mut violations = Vec::new();

    if let Some(mounts) = config.get("mounts").and_then(|v| v.as_array()) {
        for mount in mounts {
            let options = mount
                .get("options")
                .and_then(|v| v.as_array())
                .map(|arr| {
                    arr.iter()
                        .filter_map(|v| v.as_str().map(ToOwned::to_owned))
                        .collect::<Vec<String>>()
                })
                .unwrap_or_default();

            let is_rw = options.iter().any(|o| o == "rw");
            if !is_rw {
                continue;
            }

            total_rw_mounts += 1;
            let has_noexec = options.iter().any(|o| o == "noexec");
            if !has_noexec {
                let destination = mount
                    .get("destination")
                    .and_then(|v| v.as_str())
                    .unwrap_or("<unknown>")
                    .to_string();
                violations.push(RwExecViolation {
                    destination,
                    options,
                });
            }
        }
    }

    eprintln!(
        "RW_EXEC_CHECK: total_rw_mounts={} violations={}",
        total_rw_mounts,
        violations.len()
    );
    if violations.is_empty() {
        eprintln!("RW_EXEC_CHECK: OK");
    } else {
        for violation in &violations {
            eprintln!(
                "RW_EXEC_CHECK: VIOLATION destination={} options={}",
                violation.destination,
                violation.options.join(",")
            );
        }
    }

    Ok(RwExecCheckResult {
        total_rw_mounts,
        violations,
    })
}

fn ensure_mount_array(
    config: &mut serde_json::Value,
) -> Result<&mut Vec<serde_json::Value>, LoaderError> {
    if config.get("mounts").is_none() {
        config["mounts"] = serde_json::json!([]);
    }
    config["mounts"].as_array_mut().ok_or_else(|| {
        LoaderError::ExecutionFailed("config.json: mounts is not an array".to_string())
    })
}

fn upsert_mount(
    mounts: &mut Vec<serde_json::Value>,
    destination: &str,
    source: PathBuf,
    default_options: Vec<String>,
) {
    for mount in mounts.iter_mut() {
        let dst = mount
            .get("destination")
            .and_then(|v| v.as_str())
            .unwrap_or_default();
        if dst == destination {
            mount["type"] = serde_json::Value::String("bind".to_string());
            mount["source"] = serde_json::Value::String(source.to_string_lossy().into_owned());
            if mount.get("options").is_none() || !mount["options"].is_array() {
                mount["options"] = serde_json::json!(default_options);
            }
            return;
        }
    }

    mounts.push(serde_json::json!({
        "destination": destination,
        "type": "bind",
        "source": source.to_string_lossy().into_owned(),
        "options": default_options,
    }));
}

fn normalize_path(path: &Path) -> Result<String, LoaderError> {
    let raw = path.to_string_lossy();
    let trimmed = raw.trim_start_matches("./");
    if trimmed.is_empty() {
        return Err(LoaderError::ExecutionFailed(
            "vmize package contains an empty entry path".to_string(),
        ));
    }
    if trimmed.starts_with('/') || trimmed.contains("..") {
        return Err(LoaderError::ExecutionFailed(format!(
            "vmize package contains unsafe entry path: {}",
            raw
        )));
    }
    Ok(trimmed.to_string())
}

#[cfg(test)]
mod tests {
    use std::fs;

    use super::validate_rw_noexec;

    #[test]
    fn validate_rw_noexec_reports_violation() {
        let tmp = tempfile::tempdir().unwrap();
        let config_path = tmp.path().join("config.json");
        fs::write(
            &config_path,
            r#"{
  "mounts": [
    {"destination": "/data", "options": ["rbind", "rw"]},
    {"destination": "/rodata", "options": ["rbind", "ro"]}
  ]
}"#,
        )
        .unwrap();

        let result = validate_rw_noexec(&config_path).unwrap();
        assert_eq!(result.total_rw_mounts, 1);
        assert_eq!(result.violations.len(), 1);
        assert_eq!(result.violations[0].destination, "/data");
    }

    #[test]
    fn validate_rw_noexec_passes_when_noexec_exists() {
        let tmp = tempfile::tempdir().unwrap();
        let config_path = tmp.path().join("config.json");
        fs::write(
            &config_path,
            r#"{
  "mounts": [
    {"destination": "/data", "options": ["rbind", "rw", "noexec"]}
  ]
}"#,
        )
        .unwrap();

        let result = validate_rw_noexec(&config_path).unwrap();
        assert_eq!(result.total_rw_mounts, 1);
        assert!(result.violations.is_empty());
    }
}
