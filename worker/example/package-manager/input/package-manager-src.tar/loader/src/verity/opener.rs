//! dm-verity device opening and closing.

use std::path::{Path, PathBuf};
use std::process::Command;

use format::VerityMetadata;
use super::{Result, VerityError};

/// RAII wrapper for a dm-verity verified device.
pub struct VerityOpener {
    name: String,
    device_path: PathBuf,
    closed: bool,
}

impl VerityOpener {
    /// Open a dm-verity verified device.
    ///
    /// Creates /dev/mapper/<name> that provides verified access to the data.
    pub fn open(
        data_device: &Path,
        hash_device: &Path,
        metadata: &VerityMetadata,
        name: &str,
    ) -> Result<Self> {
        let veritysetup = which::which("veritysetup")
            .map_err(|_| VerityError::ToolNotFound("veritysetup".to_string()))?;

        // veritysetup open <data_device> <name> <hash_device> <root_hash>
        let status = Command::new(&veritysetup)
            .arg("open")
            .arg(data_device)
            .arg(name)
            .arg(hash_device)
            .arg(&metadata.root_hash)
            .status()?;

        if !status.success() {
            return Err(VerityError::VeritysetupFailed(format!(
                "Failed to open verity device {}",
                name
            )));
        }

        let device_path = PathBuf::from(format!("/dev/mapper/{}", name));

        Ok(Self {
            name: name.to_string(),
            device_path,
            closed: false,
        })
    }

    /// Get the verified device path (/dev/mapper/<name>).
    pub fn device_path(&self) -> &Path {
        &self.device_path
    }

    /// Get the device mapper name.
    pub fn name(&self) -> &str {
        &self.name
    }

    /// Close the dm-verity device.
    pub fn close(mut self) -> Result<()> {
        self.close_inner()?;
        self.closed = true;
        Ok(())
    }

    fn close_inner(&self) -> Result<()> {
        let veritysetup = which::which("veritysetup")
            .map_err(|_| VerityError::ToolNotFound("veritysetup".to_string()))?;

        let status = Command::new(&veritysetup)
            .arg("close")
            .arg(&self.name)
            .status()?;

        if !status.success() {
            return Err(VerityError::VeritysetupFailed(format!(
                "Failed to close verity device {}",
                self.name
            )));
        }

        Ok(())
    }
}

impl Drop for VerityOpener {
    fn drop(&mut self) {
        if !self.closed {
            let _ = self.close_inner();
        }
    }
}

#[cfg(test)]
mod tests {
    #[test]
    fn test_verity_opener() {
        // Just a compile test - actual tests require root
    }
}
