//! Verity module for setting up dm-verity verified mounts.

mod loopdev;
mod mount;
mod opener;

pub use loopdev::LoopDevice;
pub use mount::MountPoint;
pub use opener::VerityOpener;

use std::io;
use thiserror::Error;

/// Errors for verity operations in loader.
#[derive(Debug, Error)]
pub enum VerityError {
    #[error("veritysetup failed: {0}")]
    VeritysetupFailed(String),

    #[error("tool not found: {0}")]
    ToolNotFound(String),

    #[error("permission denied (root required)")]
    PermissionDenied,

    #[error("loop device error: {0}")]
    LoopDevice(String),

    #[error("mount error: {0}")]
    Mount(String),

    #[error("verification failed: {0}")]
    VerificationFailed(String),

    #[error("IO error: {0}")]
    Io(#[from] io::Error),
}

pub type Result<T> = std::result::Result<T, VerityError>;
