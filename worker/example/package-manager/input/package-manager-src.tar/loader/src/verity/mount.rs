//! Mount point management.

use std::path::{Path, PathBuf};
use std::process::Command;

use super::{Result, VerityError};

/// RAII wrapper for a mount point.
pub struct MountPoint {
    mount_path: PathBuf,
    unmounted: bool,
}

impl MountPoint {
    /// Mount a device read-only.
    pub fn mount_ro(device: &Path, mount_path: &Path, fstype: &str) -> Result<Self> {
        std::fs::create_dir_all(mount_path)?;

        let status = Command::new("mount")
            .arg("-t")
            .arg(fstype)
            .arg("-o")
            .arg("ro")
            .arg(device)
            .arg(mount_path)
            .status()?;

        if !status.success() {
            return Err(VerityError::Mount(format!(
                "Failed to mount {} at {}",
                device.display(),
                mount_path.display()
            )));
        }

        Ok(Self {
            mount_path: mount_path.to_path_buf(),
            unmounted: false,
        })
    }

    /// Get the mount path.
    pub fn path(&self) -> &Path {
        &self.mount_path
    }

    /// Unmount the filesystem.
    pub fn unmount(mut self) -> Result<()> {
        self.unmount_inner()?;
        self.unmounted = true;
        Ok(())
    }

    fn unmount_inner(&self) -> Result<()> {
        let status = Command::new("umount")
            .arg(&self.mount_path)
            .status()?;

        if !status.success() {
            return Err(VerityError::Mount(format!(
                "Failed to unmount {}",
                self.mount_path.display()
            )));
        }

        Ok(())
    }
}

impl Drop for MountPoint {
    fn drop(&mut self) {
        if !self.unmounted {
            let _ = self.unmount_inner();
        }
    }
}

#[cfg(test)]
mod tests {
    #[test]
    fn test_mount_point_path() {
        // Just a compile test - actual tests require root
    }
}
