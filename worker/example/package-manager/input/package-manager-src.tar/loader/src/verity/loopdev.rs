//! Loop device management.

use std::path::{Path, PathBuf};
use std::process::Command;

use super::{Result, VerityError};

/// RAII wrapper for a loop device.
pub struct LoopDevice {
    device_path: PathBuf,
    detached: bool,
}

impl LoopDevice {
    /// Attach a file to a loop device.
    pub fn attach(file_path: &Path) -> Result<Self> {
        let output = Command::new("losetup")
            .arg("--find")
            .arg("--show")
            .arg("--read-only")
            .arg(file_path)
            .output()?;

        if !output.status.success() {
            let stderr = String::from_utf8_lossy(&output.stderr);
            if stderr.contains("Permission denied") {
                return Err(VerityError::PermissionDenied);
            }
            return Err(VerityError::LoopDevice(stderr.to_string()));
        }

        let device_path = String::from_utf8_lossy(&output.stdout)
            .trim()
            .to_string();

        Ok(Self {
            device_path: PathBuf::from(device_path),
            detached: false,
        })
    }

    /// Get the loop device path (e.g., /dev/loop0).
    pub fn path(&self) -> &Path {
        &self.device_path
    }

    /// Detach the loop device.
    pub fn detach(mut self) -> Result<()> {
        self.detach_inner()?;
        self.detached = true;
        Ok(())
    }

    fn detach_inner(&self) -> Result<()> {
        let status = Command::new("losetup")
            .arg("--detach")
            .arg(&self.device_path)
            .status()?;

        if !status.success() {
            return Err(VerityError::LoopDevice(format!(
                "Failed to detach {}",
                self.device_path.display()
            )));
        }

        Ok(())
    }
}

impl Drop for LoopDevice {
    fn drop(&mut self) {
        if !self.detached {
            let _ = self.detach_inner();
        }
    }
}

#[cfg(test)]
mod tests {
    #[test]
    fn test_loop_device_path() {
        // Just a compile test - actual tests require root
    }
}
