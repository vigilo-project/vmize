use chrono::Utc;
use std::fs;
use std::path::Path;

use format::VerityMetadata;
use thiserror::Error;

mod config_editor;
pub mod container;
mod runc;
pub mod verity;
mod vmize;

pub use container::{
    bundle_path, list_container_ids, load_state, remove_state, save_state, state_exists,
    ContainerState, ContainerStatus, CONTAINER_DIR,
};
pub use runc::RuncRunner;
pub use verity::{LoopDevice, MountPoint, VerityOpener};

#[derive(Error, Debug)]
pub enum LoaderError {
    #[error("runc not found")]
    RuncNotFound,

    #[error("execution failed: {0}")]
    ExecutionFailed(String),

    #[error("format error: {0}")]
    Format(#[from] format::FormatError),

    #[error("verity error: {0}")]
    Verity(#[from] verity::VerityError),

    #[error("container state error: {0}")]
    ContainerState(String),

    #[error("io error: {0}")]
    Io(#[from] std::io::Error),

    #[error("json error: {0}")]
    Json(#[from] serde_json::Error),
}

/// Run a VMize package tar (rootfs.squashfs/rootfs.verity/rootfs.root_hash/config.json).
pub fn run_package(
    package_path: &Path,
    container_id: &str,
    detach: bool,
    volumes: &[String],
) -> Result<(), LoaderError> {
    if let Ok(Some(state)) = load_state(container_id) {
        match state.status {
            ContainerStatus::Running => {
                return Err(LoaderError::ExecutionFailed(format!(
                    "Container '{}' is already running",
                    container_id
                )));
            }
            ContainerStatus::Stopped | ContainerStatus::Deleted => {
                remove_state(container_id)?;
                eprintln!("Cleaned up previous container state for '{}'", container_id);
            }
        }
    }

    let runner = RuncRunner::new()?;
    let container_dir = container::bundle_path(container_id);
    let squashfs_path = container_dir.join("rootfs.squashfs");
    let hash_path = container_dir.join("rootfs.verity");
    let root_hash_path = container_dir.join("rootfs.root_hash");
    let config_path = container_dir.join("config.json");
    let squashfs_mount = container_dir.join("squashfs_mount");

    let _ = fs::remove_dir_all(&container_dir);
    fs::create_dir_all(&container_dir)?;
    fs::create_dir_all(&squashfs_mount)?;

    eprintln!("Extracting package to {}...", container_dir.display());
    vmize::extract_vmize_package(package_path, &container_dir)?;
    eprintln!("Package extracted");

    vmize::setup_vmize_runtime(&config_path, &container_dir)?;

    let root_hash = vmize::read_root_hash(&root_hash_path)?;
    let verity = VerityMetadata {
        algorithm: "sha256".to_string(),
        root_hash,
        salt: None,
        data_block_size: 4096,
        hash_block_size: 4096,
        data_size: 0,
    };

    eprintln!("Attaching squashfs to loop device...");
    let data_loop = LoopDevice::attach(&squashfs_path)?;
    eprintln!("  Data loop: {}", data_loop.path().display());

    eprintln!("Attaching hash tree to loop device...");
    let hash_loop = LoopDevice::attach(&hash_path)?;
    eprintln!("  Hash loop: {}", hash_loop.path().display());

    let verity_name = format!("verity-{}", container_id);
    eprintln!("Opening verity device: {}", verity_name);
    eprintln!("  Root hash: {}", verity.root_hash);
    let verity_dev = VerityOpener::open(data_loop.path(), hash_loop.path(), &verity, &verity_name)?;
    eprintln!("  Verity device: {}", verity_dev.device_path().display());

    eprintln!("Mounting verified squashfs...");
    let squashfs_mnt = MountPoint::mount_ro(verity_dev.device_path(), &squashfs_mount, "squashfs")?;
    eprintln!("  Squashfs mount: {}", squashfs_mnt.path().display());

    config_editor::update_config_rootfs(&container_dir, &squashfs_mount)?;
    config_editor::add_volume_mounts(&container_dir, volumes)?;
    let _rw_exec = vmize::validate_rw_noexec(&config_path)?;

    if detach {
        config_editor::disable_tty(&container_dir)?;
    } else {
        config_editor::enable_interactive(&container_dir)?;
    }

    // Validate final config after all modifications
    let config_content = fs::read_to_string(&config_path)?;
    format::validate_config(&config_content)?;

    let state = ContainerState {
        id: container_id.to_string(),
        created_at: Utc::now(),
        source_package: package_path.to_path_buf(),
        status: ContainerStatus::Running,
    };
    save_state(&state)?;
    eprintln!(
        "Container state saved to {}",
        container::state_file_path(container_id).display()
    );

    let result = if detach {
        std::mem::forget(squashfs_mnt);
        std::mem::forget(verity_dev);
        std::mem::forget(hash_loop);
        std::mem::forget(data_loop);
        runner.run_detached(&container_dir, container_id)
    } else {
        runner.run(&container_dir, container_id)
    };

    if !detach {
        if let Ok(Some(mut state)) = load_state(container_id) {
            state.status = ContainerStatus::Stopped;
            save_state(&state)?;
        }
    }

    result
}

/// Execute a command in a running container.
pub fn exec_in_container(
    container_id: &str,
    command: &[String],
    terminal: bool,
) -> Result<(), LoaderError> {
    let runner = RuncRunner::new()?;
    runner.exec(container_id, command, terminal)
}

/// List containers.
pub fn list_containers() -> Result<String, LoaderError> {
    let runner = RuncRunner::new()?;
    let runc_output = runner.list()?;

    let mut output = String::new();
    output.push_str("CONTAINER ID          STATUS     SOURCE\n");
    output.push_str("----------------------------------------------------\n");

    for id in list_container_ids()? {
        if let Ok(Some(state)) = load_state(&id) {
            let status_str = format!("{:?}", state.status).to_lowercase();
            let source = state
                .source_package
                .file_name()
                .unwrap_or_default()
                .to_string_lossy();
            output.push_str(&format!(
                "{:<20}  {:<9}  {}\n",
                state.id, status_str, source
            ));
        }
    }

    if !runc_output.is_empty() {
        output.push_str("\n--- Runc Containers ---\n");
        output.push_str(&runc_output);
    }

    Ok(output)
}

/// Kill a running container.
pub fn kill_container(container_id: &str, signal: &str) -> Result<(), LoaderError> {
    let runner = RuncRunner::new()?;
    runner.kill(container_id, signal)
}

/// Delete a container.
pub fn delete_container(container_id: &str, force: bool) -> Result<(), LoaderError> {
    let runner = RuncRunner::new()?;

    if let Err(e) = runner.delete(container_id, force) {
        eprintln!("Warning: runc delete failed: {}", e);
    }

    if let Err(e) = remove_state(container_id) {
        eprintln!("Warning: failed to remove container state: {}", e);
    }

    Ok(())
}
