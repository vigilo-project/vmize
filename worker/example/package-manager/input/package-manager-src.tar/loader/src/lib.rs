use chrono::Utc;
use std::fs;
use std::path::Path;

use format::{Package, PackageManifest, RootfsMetadata, VerityMetadata};
use tempfile::TempDir;
use thiserror::Error;

mod config_editor;
pub mod container;
mod runc;
pub mod verity;
mod vmize;

pub use container::{
    bundle_path, list_container_ids, load_state, remove_state, rootfs_path, save_state,
    state_exists, ContainerState, ContainerStatus, RootfsType, CONTAINER_DIR,
};
pub use runc::RuncRunner;
pub use verity::{LoopDevice, MountPoint, VerityOpener};

#[derive(Error, Debug)]
pub enum LoaderError {
    #[error("runc not found")]
    RuncNotFound,

    #[error("execution failed: {0}")]
    ExecutionFailed(String),

    #[error("format error: {0}")]
    Format(#[from] format::FormatError),

    #[error("verity error: {0}")]
    Verity(#[from] verity::VerityError),

    #[error("container state error: {0}")]
    ContainerState(String),

    #[error("io error: {0}")]
    Io(#[from] std::io::Error),

    #[error("json error: {0}")]
    Json(#[from] serde_json::Error),
}

pub fn extract_package(package_path: &Path) -> Result<(PackageManifest, TempDir), LoaderError> {
    let temp_dir = TempDir::new()?;
    let manifest = Package::extract(package_path, temp_dir.path())?;
    Ok((manifest, temp_dir))
}

/// Run a package, auto-detecting V1 or V2 format.
///
/// V1 packages are extracted to persistent storage and run with root.readonly = false.
/// V2 packages use dm-verity for integrity verification (immutable).
pub fn run_package(
    package_path: &Path,
    container_id: &str,
    detach: bool,
    volumes: &[String],
) -> Result<(), LoaderError> {
    // Check if container already exists
    if let Ok(Some(state)) = load_state(container_id) {
        match state.status {
            ContainerStatus::Running => {
                return Err(LoaderError::ExecutionFailed(format!(
                    "Container '{}' is already running",
                    container_id
                )));
            }
            ContainerStatus::Stopped | ContainerStatus::Deleted => {
                remove_state(container_id)?;
                eprintln!("Cleaned up previous container state for '{}'", container_id);
            }
        }
    }

    let manifest = Package::read_manifest(package_path)?;

    match &manifest.rootfs {
        RootfsMetadata::Directory => {
            eprintln!("Running V1 package (rootfs directory)");
            run_v1(package_path, container_id, detach, volumes)
        }
        RootfsMetadata::Squashfs { verity } => {
            eprintln!("Running V2 package (squashfs + dm-verity)");
            run_v2(package_path, verity, container_id, detach, volumes)
        }
    }
}

/// Run a VMize package tar (rootfs.squashfs/rootfs.verity/rootfs.root_hash/config.json).
///
/// This path keeps legacy V1/V2 flow intact and is intended for VMize integration.
pub fn run_vmize_package(
    package_path: &Path,
    container_id: &str,
    detach: bool,
    volumes: &[String],
) -> Result<(), LoaderError> {
    if let Ok(Some(state)) = load_state(container_id) {
        match state.status {
            ContainerStatus::Running => {
                return Err(LoaderError::ExecutionFailed(format!(
                    "Container '{}' is already running",
                    container_id
                )));
            }
            ContainerStatus::Stopped | ContainerStatus::Deleted => {
                remove_state(container_id)?;
                eprintln!("Cleaned up previous container state for '{}'", container_id);
            }
        }
    }

    let runner = RuncRunner::new()?;
    let container_dir = container::bundle_path(container_id);
    let squashfs_path = container_dir.join("rootfs.squashfs");
    let hash_path = container_dir.join("rootfs.verity");
    let root_hash_path = container_dir.join("rootfs.root_hash");
    let config_path = container_dir.join("config.json");
    let squashfs_mount = container_dir.join("squashfs_mount");

    let _ = fs::remove_dir_all(&container_dir);
    fs::create_dir_all(&container_dir)?;
    fs::create_dir_all(&squashfs_mount)?;

    eprintln!("Extracting vmize package to {}...", container_dir.display());
    vmize::extract_vmize_package(package_path, &container_dir)?;
    eprintln!("VMize package extracted");

    vmize::setup_vmize_runtime(&config_path, &container_dir)?;

    let root_hash = vmize::read_root_hash(&root_hash_path)?;
    let verity = VerityMetadata {
        algorithm: "sha256".to_string(),
        root_hash,
        salt: None,
        data_block_size: 4096,
        hash_block_size: 4096,
        data_size: 0,
    };

    eprintln!("Attaching squashfs to loop device...");
    let data_loop = LoopDevice::attach(&squashfs_path)?;
    eprintln!("  Data loop: {}", data_loop.path().display());

    eprintln!("Attaching hash tree to loop device...");
    let hash_loop = LoopDevice::attach(&hash_path)?;
    eprintln!("  Hash loop: {}", hash_loop.path().display());

    let verity_name = format!("verity-{}", container_id);
    eprintln!("Opening verity device: {}", verity_name);
    eprintln!("  Root hash: {}", verity.root_hash);
    let verity_dev = VerityOpener::open(data_loop.path(), hash_loop.path(), &verity, &verity_name)?;
    eprintln!("  Verity device: {}", verity_dev.device_path().display());

    eprintln!("Mounting verified squashfs...");
    let squashfs_mnt = MountPoint::mount_ro(verity_dev.device_path(), &squashfs_mount, "squashfs")?;
    eprintln!("  Squashfs mount: {}", squashfs_mnt.path().display());

    config_editor::update_config_rootfs(&container_dir, &squashfs_mount)?;
    config_editor::add_volume_mounts(&container_dir, volumes)?;
    let _rw_exec = vmize::validate_rw_noexec(&config_path)?;

    if detach {
        config_editor::disable_tty(&container_dir)?;
    } else {
        config_editor::enable_interactive(&container_dir)?;
    }

    let state = ContainerState {
        id: container_id.to_string(),
        created_at: Utc::now(),
        source_package: package_path.to_path_buf(),
        status: ContainerStatus::Running,
        writable: false,
        rootfs_type: RootfsType::Squashfs,
    };
    save_state(&state)?;
    eprintln!(
        "Container state saved to {}",
        container::state_file_path(container_id).display()
    );

    let result = if detach {
        std::mem::forget(squashfs_mnt);
        std::mem::forget(verity_dev);
        std::mem::forget(hash_loop);
        std::mem::forget(data_loop);
        runner.run_detached(&container_dir, container_id)
    } else {
        runner.run(&container_dir, container_id)
    };

    if !detach {
        if let Ok(Some(mut state)) = load_state(container_id) {
            state.status = ContainerStatus::Stopped;
            save_state(&state)?;
        }
    }

    result
}

/// Run a V1 package (rootfs directory).
///
/// Package is extracted to persistent storage at:
///   /var/lib/package-manager/containers/<id>/
///
/// Config is modified to set root.readonly = false for writable rootfs.
fn run_v1(
    package_path: &Path,
    container_id: &str,
    detach: bool,
    volumes: &[String],
) -> Result<(), LoaderError> {
    let runner = RuncRunner::new()?;

    let container_dir = container::bundle_path(container_id);
    let rootfs_dir = container::rootfs_path(container_id);

    fs::create_dir_all(&container_dir)?;
    let _ = fs::remove_dir_all(&rootfs_dir);

    eprintln!("Extracting package to {}...", container_dir.display());
    let _manifest = Package::extract(package_path, &container_dir)?;
    eprintln!("Package extracted");

    config_editor::setup_container_fs(&container_dir)?;
    config_editor::update_config_writable(&container_dir)?;
    config_editor::add_volume_mounts(&container_dir, volumes)?;

    if detach {
        config_editor::enable_build_mode(&container_dir)?;
    } else {
        config_editor::enable_interactive(&container_dir)?;
    }

    // Save container state
    let state = ContainerState {
        id: container_id.to_string(),
        created_at: Utc::now(),
        source_package: package_path.to_path_buf(),
        status: ContainerStatus::Running,
        writable: true,
        rootfs_type: RootfsType::Directory,
    };
    save_state(&state)?;
    eprintln!(
        "Container state saved to {}",
        container::state_file_path(container_id).display()
    );

    if detach {
        runner.run_detached(&container_dir, container_id)?;
    } else {
        runner.run(&container_dir, container_id)?;
    }

    // Update state to stopped after container exits
    if let Ok(Some(mut state)) = load_state(container_id) {
        state.status = ContainerStatus::Stopped;
        save_state(&state)?;
    }

    Ok(())
}

/// Run a V2 package with dm-verity verification.
///
/// V2 packages are immutable (protected by dm-verity) and use direct squashfs mount.
fn run_v2(
    package_path: &Path,
    verity: &VerityMetadata,
    container_id: &str,
    detach: bool,
    volumes: &[String],
) -> Result<(), LoaderError> {
    let runner = RuncRunner::new()?;

    let container_dir = container::bundle_path(container_id);
    let squashfs_path = container_dir.join("rootfs.squashfs");
    let hash_path = container_dir.join("rootfs.squashfs.hash");
    let squashfs_mount = container_dir.join("squashfs_mount");
    let rootfs_path = container_dir.join("rootfs");

    fs::create_dir_all(&container_dir)?;
    fs::create_dir_all(&squashfs_mount)?;
    fs::create_dir_all(&rootfs_path)?;

    eprintln!("Extracting package to {}...", container_dir.display());
    let _manifest = Package::extract(package_path, &container_dir)?;
    eprintln!("Package extracted");

    // Move config.json from rootfs_path to container_dir
    let src_config = rootfs_path.join("config.json");
    let dst_config = container_dir.join("config.json");
    if src_config.exists() {
        fs::rename(&src_config, &dst_config)?;
    }

    // Setup loop devices and verity
    eprintln!("Attaching squashfs to loop device...");
    let data_loop = LoopDevice::attach(&squashfs_path)?;
    eprintln!("  Data loop: {}", data_loop.path().display());

    eprintln!("Attaching hash to loop device...");
    let hash_loop = LoopDevice::attach(&hash_path)?;
    eprintln!("  Hash loop: {}", hash_loop.path().display());

    let verity_name = format!("verity-{}", container_id);
    eprintln!("Opening verity device: {}", verity_name);
    eprintln!("  Root hash: {}", verity.root_hash);
    let verity_dev = VerityOpener::open(data_loop.path(), hash_loop.path(), verity, &verity_name)?;
    eprintln!("  Verity device: {}", verity_dev.device_path().display());

    eprintln!("Mounting verified squashfs...");
    let squashfs_mnt = MountPoint::mount_ro(verity_dev.device_path(), &squashfs_mount, "squashfs")?;
    eprintln!("  Squashfs mount: {}", squashfs_mnt.path().display());

    config_editor::update_config_rootfs(&container_dir, &squashfs_mount)?;
    config_editor::add_volume_mounts(&container_dir, volumes)?;

    if detach {
        config_editor::disable_tty(&container_dir)?;
        eprintln!("V2 container running in detached mode (TTY disabled)");
    } else {
        config_editor::enable_interactive(&container_dir)?;
    }

    // Save container state
    let state = ContainerState {
        id: container_id.to_string(),
        created_at: Utc::now(),
        source_package: package_path.to_path_buf(),
        status: ContainerStatus::Running,
        writable: false,
        rootfs_type: RootfsType::Squashfs,
    };
    save_state(&state)?;
    eprintln!(
        "Container state saved to {}",
        container::state_file_path(container_id).display()
    );

    let result = if detach {
        // Keep resources alive for detached mode
        std::mem::forget(squashfs_mnt);
        std::mem::forget(verity_dev);
        std::mem::forget(hash_loop);
        std::mem::forget(data_loop);
        runner.run_detached(&container_dir, container_id)
    } else {
        runner.run(&container_dir, container_id)
    };

    // Update state to stopped after container exits (non-detached only)
    if !detach {
        if let Ok(Some(mut state)) = load_state(container_id) {
            state.status = ContainerStatus::Stopped;
            save_state(&state)?;
        }
    }

    result
}

/// Execute a command in a running container.
pub fn exec_in_container(
    container_id: &str,
    command: &[String],
    terminal: bool,
) -> Result<(), LoaderError> {
    let runner = RuncRunner::new()?;
    runner.exec(container_id, command, terminal)
}

/// List containers (both runc and persistent writable containers).
pub fn list_containers() -> Result<String, LoaderError> {
    let runner = RuncRunner::new()?;
    let runc_output = runner.list()?;

    let mut output = String::new();
    output.push_str("CONTAINER ID          STATUS     WRITABLE  SOURCE\n");
    output.push_str("----------------------------------------------------------------\n");

    for id in list_container_ids()? {
        if let Ok(Some(state)) = load_state(&id) {
            let status_str = format!("{:?}", state.status).to_lowercase();
            let writable_str = if state.writable { "yes" } else { "no" };
            let source = state
                .source_package
                .file_name()
                .unwrap_or_default()
                .to_string_lossy();
            output.push_str(&format!(
                "{:<20}  {:<9}  {:<8}  {}\n",
                state.id, status_str, writable_str, source
            ));
        }
    }

    if !runc_output.is_empty() {
        output.push_str("\n--- Runc Containers (non-writable) ---\n");
        output.push_str(&runc_output);
    }

    Ok(output)
}

/// Kill a running container.
pub fn kill_container(container_id: &str, signal: &str) -> Result<(), LoaderError> {
    let runner = RuncRunner::new()?;
    runner.kill(container_id, signal)
}

/// Delete a container.
pub fn delete_container(container_id: &str, force: bool) -> Result<(), LoaderError> {
    let runner = RuncRunner::new()?;

    if let Err(e) = runner.delete(container_id, force) {
        eprintln!("Warning: runc delete failed: {}", e);
    }

    if let Err(e) = remove_state(container_id) {
        eprintln!("Warning: failed to remove container state: {}", e);
    }

    Ok(())
}

/// Commit container changes to a new V1 package.
///
/// Since V1 uses direct rootfs (no OverlayFS), this copies the modified rootfs directly.
pub fn commit_container(
    container_id: &str,
    output_path: &Path,
    message: Option<&str>,
    remove_container: bool,
) -> Result<(), LoaderError> {
    let state = load_state(container_id)?.ok_or_else(|| {
        LoaderError::ContainerState(format!("Container '{}' not found", container_id))
    })?;

    if !state.writable {
        return Err(LoaderError::ContainerState(format!(
            "Container '{}' is not writable",
            container_id
        )));
    }

    let rootfs_dir = container::rootfs_path(container_id);

    if !rootfs_dir.exists() {
        return Err(LoaderError::ContainerState(format!(
            "Container rootfs not found at {}",
            rootfs_dir.display()
        )));
    }

    eprintln!("Committing container '{}'...", container_id);

    let temp_dir = tempfile::Builder::new().prefix("commit-").tempdir()?;
    let commit_rootfs = temp_dir.path().join("rootfs");

    eprintln!("Copying rootfs...");
    copy_directory(&rootfs_dir, &commit_rootfs)?;

    // Read original config from source package (not the modified bundle config).
    // The bundle config has sleep infinity which we don't want in the committed package.
    let (config_json, orig_manifest) = {
        let temp = tempfile::TempDir::new()?;
        let _ = Package::extract(&state.source_package, temp.path())?;
        let config = fs::read_to_string(temp.path().join("config.json"))
            .unwrap_or_else(|_| "{}".to_string());
        let manifest = fs::read_to_string(temp.path().join("manifest.json")).ok();
        (config, manifest)
    };

    let manifest: format::PackageManifest = if let Some(ref json) = orig_manifest {
        serde_json::from_str(json)?
    } else {
        format::PackageManifest::new(
            state.id.clone(),
            format!("committed-{}", chrono::Utc::now().timestamp()),
            state.source_package.to_string_lossy().to_string(),
        )
    };

    if let Some(msg) = message {
        eprintln!("Commit message: {}", msg);
    }

    eprintln!("Creating package at {}...", output_path.display());
    format::Package::create(output_path, &commit_rootfs, &config_json, &manifest)?;
    eprintln!("Package created successfully at {}", output_path.display());

    if remove_container {
        eprintln!("Removing container state...");
        remove_state(container_id)?;
    }

    Ok(())
}

/// Recursively copy a directory.
///
/// Handles regular files, directories, and symlinks.
/// Skips special files (sockets, device nodes, FIFOs) that cannot be copied.
fn copy_directory(src: &Path, dst: &Path) -> std::io::Result<()> {
    if src.is_dir() {
        fs::create_dir_all(dst)?;
        for entry in fs::read_dir(src)? {
            let entry = entry?;
            let file_type = entry.file_type()?;
            let dst_path = dst.join(entry.file_name());

            if file_type.is_dir() {
                copy_directory(&entry.path(), &dst_path)?;
            } else if file_type.is_symlink() {
                let link_target = fs::read_link(entry.path())?;
                #[cfg(unix)]
                std::os::unix::fs::symlink(&link_target, &dst_path)?;
            } else if file_type.is_file() {
                fs::copy(entry.path(), &dst_path)?;
            }
            // Skip special files: sockets, device nodes, FIFOs
        }
    } else if src.is_file() {
        fs::copy(src, dst)?;
    }
    Ok(())
}
