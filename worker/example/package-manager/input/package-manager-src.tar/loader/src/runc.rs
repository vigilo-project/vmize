use std::path::{Path, PathBuf};
use std::process::{Command, Stdio};

use crate::LoaderError;

pub struct RuncRunner {
    runc_path: PathBuf,
}

impl RuncRunner {
    pub fn new() -> Result<Self, LoaderError> {
        let runc_path = which::which("runc")
            .map_err(|_| LoaderError::RuncNotFound)?;

        Ok(Self { runc_path })
    }

    /// Run a container (foreground or detached).
    pub fn run(&self, bundle_path: &Path, container_id: &str) -> Result<(), LoaderError> {
        self.run_inner(bundle_path, container_id, false)
    }

    /// Run a container in detached mode.
    pub fn run_detached(&self, bundle_path: &Path, container_id: &str) -> Result<(), LoaderError> {
        self.run_inner(bundle_path, container_id, true)
    }

    fn run_inner(
        &self,
        bundle_path: &Path,
        container_id: &str,
        detach: bool,
    ) -> Result<(), LoaderError> {
        let bundle_abs = bundle_path
            .canonicalize()
            .map_err(|e| LoaderError::ExecutionFailed(format!("Invalid bundle path: {}", e)))?;

        let mut cmd = Command::new(&self.runc_path);
        cmd.arg("run");

        if detach {
            cmd.arg("--detach");
        }

        cmd.arg("--bundle")
            .arg(&bundle_abs)
            .arg(container_id)
            .stdin(Stdio::inherit())
            .stdout(Stdio::inherit())
            .stderr(Stdio::inherit());

        self.exec_status(cmd, "runc run")
    }

    /// Execute a command in a running container.
    pub fn exec(
        &self,
        container_id: &str,
        command: &[String],
        terminal: bool,
    ) -> Result<(), LoaderError> {
        if command.is_empty() {
            return Err(LoaderError::ExecutionFailed(
                "exec requires at least one command argument".to_string(),
            ));
        }

        let mut cmd = Command::new(&self.runc_path);
        cmd.arg("exec");

        if terminal {
            cmd.arg("-t");
        }

        cmd.arg(container_id)
            .args(command)
            .stdin(Stdio::inherit())
            .stdout(Stdio::inherit())
            .stderr(Stdio::inherit());

        self.exec_status(cmd, "runc exec")
    }

    /// List running containers.
    pub fn list(&self) -> Result<String, LoaderError> {
        let output = Command::new(&self.runc_path)
            .arg("list")
            .output()
            .map_err(|e| LoaderError::ExecutionFailed(format!("Failed to execute runc list: {}", e)))?;

        Ok(String::from_utf8_lossy(&output.stdout).into_owned())
    }

    /// Kill a container.
    pub fn kill(&self, container_id: &str, signal: &str) -> Result<(), LoaderError> {
        let cmd = Command::new(&self.runc_path)
            .arg("kill")
            .arg(container_id)
            .arg(signal)
            .stdin(Stdio::null())
            .stdout(Stdio::inherit())
            .stderr(Stdio::inherit())
            .status()
            .map_err(|e| LoaderError::ExecutionFailed(format!("Failed to execute runc kill: {}", e)))?;

        if !cmd.success() {
            return Err(LoaderError::ExecutionFailed(format!(
                "runc kill exited with status: {}",
                cmd
            )));
        }

        Ok(())
    }

    /// Delete a container.
    pub fn delete(&self, container_id: &str, force: bool) -> Result<(), LoaderError> {
        let mut cmd = Command::new(&self.runc_path);
        cmd.arg("delete");

        if force {
            cmd.arg("--force");
        }

        cmd.arg(container_id);

        self.exec_status(cmd, "runc delete")
    }

    /// Execute a command and check its exit status.
    fn exec_status(&self, mut cmd: Command, label: &str) -> Result<(), LoaderError> {
        let status = cmd
            .status()
            .map_err(|e| LoaderError::ExecutionFailed(format!("Failed to execute {}: {}", label, e)))?;

        if !status.success() {
            return Err(LoaderError::ExecutionFailed(format!(
                "{} exited with status: {}",
                label, status
            )));
        }

        Ok(())
    }
}
