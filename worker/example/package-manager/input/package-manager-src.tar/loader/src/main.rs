use std::path::PathBuf;

use clap::Parser;

use loader::{
    commit_container, delete_container, exec_in_container, kill_container, list_containers,
    run_package, run_vmize_package,
};

#[derive(Parser, Debug)]
#[command(name = "loader", version, about = "Run container packages")]
struct Cli {
    #[command(subcommand)]
    command: Commands,
}

#[derive(clap::Subcommand, Debug)]
enum Commands {
    /// Run a container from a package (runc-compatible: loader run <id> --pkg <pkg>)
    Run {
        /// Container ID
        id: String,

        /// Package path (tar.gz)
        #[arg(long, short = 'p')]
        pkg: PathBuf,

        /// Run container detached
        #[arg(long, short = 'd')]
        detach: bool,

        /// Bind mount volumes (format: host:container[:ro])
        #[arg(short = 'v', long = "volume", action = clap::ArgAction::Append)]
        volumes: Vec<String>,
    },

    /// Run a VMize package tar via loader+runc wrapper
    RunVmize {
        /// Container ID
        id: String,

        /// VMize package path (tar)
        #[arg(long, short = 'p')]
        pkg: PathBuf,

        /// Run container detached
        #[arg(long, short = 'd')]
        detach: bool,

        /// Bind mount volumes (format: host:container[:ro])
        #[arg(short = 'v', long = "volume", action = clap::ArgAction::Append)]
        volumes: Vec<String>,
    },

    /// Execute a command in a running container (runc-compatible: loader exec <id> <cmd>)
    Exec {
        /// Container ID
        id: String,

        /// Command to execute
        command: Vec<String>,

        /// Enable TTY for interactive use
        #[arg(short = 't', long)]
        tty: bool,
    },

    /// List running containers
    List,

    /// Kill a running container (runc-compatible: loader kill <id> [<signal>])
    Kill {
        /// Container ID
        id: String,

        /// Signal to send (default: SIGTERM)
        signal: Option<String>,
    },

    /// Delete a container (runc-compatible: loader delete <id>)
    Delete {
        /// Container ID
        id: String,

        /// Force deletion even if running
        #[arg(long, short = 'f')]
        force: bool,
    },

    /// Commit container changes to a new package
    Commit {
        /// Container ID
        id: String,

        /// Output package path (tar.gz)
        #[arg(short, long)]
        output: PathBuf,

        /// Commit message
        #[arg(short, long)]
        message: Option<String>,

        /// Remove container after commit
        #[arg(long)]
        rm: bool,
    },
}

fn main() -> anyhow::Result<()> {
    let cli = Cli::parse();

    match cli.command {
        Commands::Run {
            id,
            pkg,
            detach,
            volumes,
        } => {
            run_package(&pkg, &id, detach, &volumes)?;
        }
        Commands::RunVmize {
            id,
            pkg,
            detach,
            volumes,
        } => {
            run_vmize_package(&pkg, &id, detach, &volumes)?;
        }
        Commands::Exec { id, command, tty } => {
            exec_in_container(&id, &command, tty)?;
        }
        Commands::List => {
            let output = list_containers()?;
            print!("{}", output);
        }
        Commands::Kill { id, signal } => {
            let sig = signal.unwrap_or_else(|| "SIGTERM".to_string());
            kill_container(&id, &sig)?;
            eprintln!("Container {} killed with {}", id, sig);
        }
        Commands::Delete { id, force } => {
            delete_container(&id, force)?;
            eprintln!("Container {} deleted", id);
        }
        Commands::Commit {
            id,
            output,
            message,
            rm,
        } => {
            commit_container(&id, &output, message.as_deref(), rm)?;
            eprintln!("Container {} committed to {}", id, output.display());
        }
    }

    Ok(())
}
