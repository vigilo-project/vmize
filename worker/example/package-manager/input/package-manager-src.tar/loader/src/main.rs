use std::path::PathBuf;

use clap::Parser;

use loader::{delete_container, exec_in_container, kill_container, list_containers, run_package};

#[derive(Parser, Debug)]
#[command(name = "loader", version, about = "Run container packages")]
struct Cli {
    #[command(subcommand)]
    command: Commands,
}

#[derive(clap::Subcommand, Debug)]
enum Commands {
    /// Run a container from a package
    Run {
        /// Container ID
        id: String,

        /// Package path (tar)
        #[arg(long, short = 'p')]
        pkg: PathBuf,

        /// Run container detached
        #[arg(long, short = 'd')]
        detach: bool,

        /// Bind mount volumes (format: host:container[:ro])
        #[arg(short = 'v', long = "volume", action = clap::ArgAction::Append)]
        volumes: Vec<String>,
    },

    /// Execute a command in a running container
    Exec {
        /// Container ID
        id: String,

        /// Command to execute
        command: Vec<String>,

        /// Enable TTY for interactive use
        #[arg(short = 't', long)]
        tty: bool,
    },

    /// List running containers
    List,

    /// Kill a running container
    Kill {
        /// Container ID
        id: String,

        /// Signal to send (default: SIGTERM)
        signal: Option<String>,
    },

    /// Delete a container
    Delete {
        /// Container ID
        id: String,

        /// Force deletion even if running
        #[arg(long, short = 'f')]
        force: bool,
    },
}

fn main() -> anyhow::Result<()> {
    let cli = Cli::parse();

    match cli.command {
        Commands::Run {
            id,
            pkg,
            detach,
            volumes,
        } => {
            run_package(&pkg, &id, detach, &volumes)?;
        }
        Commands::Exec { id, command, tty } => {
            exec_in_container(&id, &command, tty)?;
        }
        Commands::List => {
            let output = list_containers()?;
            print!("{}", output);
        }
        Commands::Kill { id, signal } => {
            let sig = signal.unwrap_or_else(|| "SIGTERM".to_string());
            kill_container(&id, &sig)?;
            eprintln!("Container {} killed with {}", id, sig);
        }
        Commands::Delete { id, force } => {
            delete_container(&id, force)?;
            eprintln!("Container {} deleted", id);
        }
    }

    Ok(())
}
